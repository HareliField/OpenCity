global.CANNON=require('cannon-es');
const P=require('/home/claude/v3/js/phys.js');
const SPEC=JSON.parse(process.argv[2]||'{}');
const base={L:4.6,W:1.86,b:.95,r:1.42,hood:1.25,tr:.95,mass:1400,com:.5,wr:.34,k:26,rest:.34,gripF:1.35,gripR:1.5,roll:.6,F:8500,brake:55,max:36,awd:false};
const s=Object.assign(base,SPEC);
function mk(x,z,h){const c={spec:s,pos:{x,y:0,z,set(a,b,c){this.x=a;this.y=b;this.z=c}},vel:{set(){}},h,speed:0,hp:100,max:100};P.physCarOn(c);return c;}
P.physInit();
const run=(c,thr,st,hb,T,log)=>{for(let i=0;i<T*60;i++){P.physCarRead(c);P.physCarControl(c,thr,st,hb,1/60);P.physStep(1/60);if(log&&i%30===29){P.physCarRead(c);console.log(log,((i+1)/60).toFixed(1)+'s','pos',c.pos.x.toFixed(1),c.pos.z.toFixed(1),'y',c.body.position.y.toFixed(2),'h',c.h.toFixed(2),'v',c.speed.toFixed(1),'up',c.upY.toFixed(2),'wog',c.veh.numWheelsOnGround);}}P.physCarRead(c);};
let c=mk(0,0,0);
run(c,0,0,false,1,'settle');
let t100=null;for(let i=0;i<60*25;i++){P.physCarRead(c);P.physCarControl(c,1,0,false,1/60);P.physStep(1/60);P.physCarRead(c);if(t100===null&&c.speed>27.8)t100=i/60;}
console.log('0-100:',t100,'top',c.speed.toFixed(1),'pos',c.pos.x.toFixed(1),c.pos.z.toFixed(1));
let d0=c.pos.z,i=0;while(c.speed>.5&&i<1000){P.physCarRead(c);P.physCarControl(c,-1,0,false,1/60);P.physStep(1/60);i++;}
console.log('brake time',i/60,'dist',(c.pos.z-d0).toFixed(1));
P.physCarSet(c,0,0,0,0);run(c,1,0,false,3);console.log('speed before turn',c.speed.toFixed(1));run(c,.5,1,false,2,'turnL(steer=+1)');
P.physCarSet(c,0,0,0,0);run(c,1,0,false,6);console.log('fast',c.speed.toFixed(1));run(c,1,1,false,3,'fastturn');
P.physCarSet(c,0,0,0,0);run(c,1,0,false,4);run(c,0,1,true,2.5,'handbrake');
// wall
P.physBox(-10,10,0,10,400,410);P.physCarSet(c,0,300,0,0);run(c,1,0,false,6,'wall');console.log(P.PH.hits.slice(-3).map(h=>h.iv.toFixed(1)));
// curb
P.physBox(100,160,0,.22,-10,10);P.physCarSet(c,80,0,Math.PI/2,0);run(c,.6,0,false,5,'curb');
