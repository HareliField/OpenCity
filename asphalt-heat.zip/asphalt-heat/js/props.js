/* ================= knockable street furniture (instanced + streamed rigid bodies) ================= */
const PROPS={types:{},list:[],glow:null};
function propGeo(parts){return mergeGeos(parts.map(([g,x,y,z,rx,ry,rz])=>{g=g.clone();if(rx)g.rotateX(rx);if(ry)g.rotateY(ry);if(rz)g.rotateZ(rz);g.translate(x||0,y||0,z||0);return g;}));}
function initProps(){const C=(r0,r1,h,s=10)=>new THREE.CylinderGeometry(r0,r1,h,s),B=(x,y,z)=>new THREE.BoxGeometry(x,y,z);
 const red=new THREE.MeshStandardMaterial({color:lin(0xb82a1e),roughness:.45,metalness:.3}),green=new THREE.MeshStandardMaterial({color:lin(0x2c4a30),roughness:.55,metalness:.3}),blue=new THREE.MeshStandardMaterial({color:lin(0x24448a),roughness:.45,metalness:.3}),orange=new THREE.MeshStandardMaterial({color:lin(0xff5a10),roughness:.6}),yellowM=new THREE.MeshStandardMaterial({color:lin(0xd8a020),roughness:.5,metalness:.2});
 const T=PROPS.types;
 T.lamp={geo:propGeo([[C(.07,.12,7.2,8),0,3.6,0],[B(.09,.09,2),0,7.1,.95],[B(.42,.14,.75),0,7.0,1.85]]),mat:MAT.darkMetal,shape:()=>new CANNON.Box(new CV(.12,3.6,.12)),off:new CV(0,3.6,0),mass:220,glow:1};
 T.hydrant={geo:propGeo([[C(.17,.2,.62,10),0,.31,0],[C(.21,.21,.08,10),0,.64,0],[C(.12,.15,.16,10),0,.75,0],[C(.07,.07,.42,8),0,.42,0,0,0,Math.PI/2]]),mat:red,shape:()=>new CANNON.Cylinder(.2,.2,.8,8),off:new CV(0,.4,0),mass:90,spray:1};
 T.bin={geo:propGeo([[C(.3,.27,.95,12),0,.47,0],[C(.33,.33,.06,12),0,.97,0]]),mat:green,shape:()=>new CANNON.Cylinder(.31,.31,1,10),off:new CV(0,.5,0),mass:22};
 T.news={geo:propGeo([[B(.5,.95,.45),0,.6,0],[B(.46,.12,.04),0,.82,.24]]),mat:blue,shape:()=>new CANNON.Box(new CV(.25,.55,.23)),off:new CV(0,.55,0),mass:28};
 T.meter={geo:propGeo([[C(.04,.04,1.2,6),0,.6,0],[B(.2,.32,.16),0,1.32,0]]),mat:MAT.metal,shape:()=>new CANNON.Box(new CV(.1,.75,.1)),off:new CV(0,.75,0),mass:14};
 T.bench={geo:propGeo([[B(2,.07,.48),0,.47,0],[B(2,.42,.06),0,.78,-.22,-.2],[B(.07,.47,.46),-.9,.23,0],[B(.07,.47,.46),.9,.23,0]]),mat:MAT.wood,shape:()=>new CANNON.Box(new CV(1,.45,.27)),off:new CV(0,.45,0),mass:45};
 T.bollard={geo:propGeo([[C(.11,.13,.9,10),0,.45,0],[C(.12,.12,.06,10),0,.92,0]]),mat:MAT.darkMetal,shape:()=>new CANNON.Cylinder(.13,.13,.95,8),off:new CV(0,.47,0),mass:70};
 T.cone={geo:propGeo([[new THREE.ConeGeometry(.17,.68,12),0,.38,0],[B(.36,.04,.36),0,.02,0]]),mat:orange,shape:()=>new CANNON.Box(new CV(.16,.35,.16)),off:new CV(0,.35,0),mass:3};
 T.barrel={geo:propGeo([[C(.29,.29,.88,14),0,.44,0]]),mat:yellowM,shape:()=>new CANNON.Cylinder(.3,.3,.9,10),off:new CV(0,.45,0),mass:35};
 T.mailbox={geo:propGeo([[C(.04,.04,1,6),0,.5,0],[B(.24,.26,.46),0,1.1,0]]),mat:MAT.darkMetal,shape:()=>new CANNON.Box(new CV(.13,.65,.24)),off:new CV(0,.65,0),mass:12};
 const spots=[...PROPSPOTS];for(const L of LAMPS)spots.push({type:'lamp',x:L.x,z:L.z,ry:L.ry});
 const byType={};for(const s of spots){(byType[s.type]=byType[s.type]||[]).push(s);}
 const o=new THREE.Object3D();
 for(const t in byType){const P=T[t];const arr=byType[t];const im=new THREE.InstancedMesh(P.geo,P.mat,arr.length);im.castShadow=true;im.receiveShadow=true;im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);P.mesh=im;if(LOWSHADOW)im.layers.set(2);scene.add(im);
  arr.forEach((s,k)=>{const y=blockY(s.x,s.z);o.position.set(s.x,y,s.z);o.rotation.set(0,s.ry||0,0);o.updateMatrix();im.setMatrixAt(k,o.matrix);PROPS.list.push({t,P,x:s.x,y,z:s.z,ry:s.ry||0,idx:k,body:null,moved:false,broken:false,spray:0});});}
 /* lamp glows */
 const lamps=PROPS.list.filter(p=>p.t==='lamp');const gp=new Float32Array(lamps.length*3),gc=new Float32Array(lamps.length*3);
 lamps.forEach((p,k)=>{p.gi=k;gp[k*3]=p.x+Math.sin(p.ry)*1.85;gp[k*3+1]=p.y+6.9;gp[k*3+2]=p.z+Math.cos(p.ry)*1.85;gc[k*3]=1;gc[k*3+1]=.72;gc[k*3+2]=.42;});
 const gg=new THREE.BufferGeometry();gg.setAttribute('position',new THREE.BufferAttribute(gp,3));gg.setAttribute('color',new THREE.BufferAttribute(gc,3));
 PROPS.glow=new THREE.Points(gg,new THREE.PointsMaterial({map:glowTex(),size:2.4,vertexColors:true,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,opacity:.9}));PROPS.glow.frustumCulled=false;scene.add(PROPS.glow);
 const head=new THREE.InstancedMesh(new THREE.PlaneGeometry(.36,.66).rotateX(Math.PI/2),new THREE.MeshBasicMaterial({color:new THREE.Color(3,2.3,1.5)}),lamps.length);lamps.forEach((p,k)=>{o.position.set(gp[k*3],gp[k*3+1]-.08,gp[k*3+2]);o.rotation.set(0,p.ry,0);o.updateMatrix();head.setMatrixAt(k,o.matrix);});PROPS.heads=head;scene.add(head);}
let _glowT=null;function glowTex(){if(_glowT)return _glowT;const[c,g]=cvs(64,64);const gr=g.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.2,'rgba(255,255,255,.55)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);return _glowT=new THREE.CanvasTexture(c);}
function blockY(x,z){return blockOf(x,z)?.15:0;}
const _po=new THREE.Object3D();let propT=0;
function updProps(dt,px,pz){propT-=dt;
 if(propT<=0){propT=.4;for(const p of PROPS.list){const d=Math.hypot(p.x-px,p.z-pz);
  if(!p.body&&!p.broken&&d<55){const b=physDyn(p.P.shape(),p.P.mass,p.x,p.y,p.z,p.P.off);b.quaternion.setFromEuler(0,p.ry,0);b.sleep();b.prop=p;p.body=b;
   b.addEventListener('collide',e=>{if(p.broken)return;const iv=Math.abs(e.contact.getImpactVelocityAlongNormal());if(iv>2.5&&e.body.car){p.moved=true;if(p.P.spray&&!p.spray){p.spray=9;}if(p.P.glow&&p.gi!=null){const c=PROPS.glow.geometry.attributes.color;c.setXYZ(p.gi,0,0,0);c.needsUpdate=true;_po.position.set(0,-99,0);_po.updateMatrix();PROPS.heads.setMatrixAt(p.gi,_po.matrix);PROPS.heads.instanceMatrix.needsUpdate=true;}
    if(typeof onPropHit==='function')onPropHit(p,iv,e.body.car);}});}
  else if(p.body&&d>80){if(!p.moved||p.body.sleepState===2){physRemove(p.body);p.body=null;if(p.moved)p.broken=true;}}}}
 for(const t in PROPS.types){const P=PROPS.types[t];if(P.dirty){P.mesh.instanceMatrix.needsUpdate=true;P.dirty=false;}}
 for(const p of PROPS.list){if(!p.body||p.body.sleepState===2)continue;const b=p.body;_po.position.set(b.position.x,b.position.y,b.position.z);_po.quaternion.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w);
  _v.copy(p.P.off).applyQuaternion(_po.quaternion);_po.position.sub(_v);_po.scale.set(1,1,1);_po.updateMatrix();p.P.mesh.setMatrixAt(p.idx,_po.matrix);p.P.dirty=true;}
 for(const p of PROPS.list)if(p.spray>0){p.spray-=dt;if(typeof emit==='function'&&Math.random()<.9){emit(p.x+rnd(-.1,.1),.6,p.z+rnd(-.1,.1),rnd(-1.2,1.2),rnd(9,13),rnd(-1.2,1.2),1.1,.35,1.4,0xd8e8f2,false,9.8);}}}
