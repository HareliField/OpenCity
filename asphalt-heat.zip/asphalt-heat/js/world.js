/* ================= world: materials, districts, buildings, streets, props ================= */
const TLD=new THREE.TextureLoader();const TEXC={};
function T(name,kind,rep,srgb){const k=name+kind+(rep||1);let t=TEXC[k];if(!t){t=TLD.load('tex/'+name+'_'+kind+'.webp');t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=8;if(srgb)t.encoding=THREE.sRGBEncoding;if(rep)t.repeat.set(rep,rep);TEXC[k]=t;}return t;}
function pbr(name,meters,o={}){const r=1/meters;const m=new THREE.MeshStandardMaterial(Object.assign({map:T(name,'d',r,true),normalMap:T(name,'n',r),normalScale:new THREE.Vector2(o.ns||1,o.ns||1),roughness:o.rough==null?.9:o.rough,metalness:o.metal||0,envMapIntensity:o.env==null?.6:o.env},o.extra||{}));if(o.rmap)m.roughnessMap=T(name,'r',r);if(o.color)m.color=lin(o.color);return m;}
/* ---- facade shader: windows with parallax interiors, frames, shop fronts ---- */
const FACV=`attribute vec4 fac;attribute vec2 fac2;varying vec4 vFac;varying vec2 vFac2;varying vec2 vFU;varying vec3 vWP2;varying vec3 vWN;`;
const FACF=`varying vec4 vFac;varying vec2 vFac2;varying vec2 vFU;varying vec3 vWP2;varying vec3 vWN;`+WETCODE;
const FACMAIN=`#include <map_fragment>
 float glass=0.,frame=0.,metalG=0.;vec3 emitW=vec3(0.);vec3 frameC=vec3(.05);
 {float seed=floor(vFac.x*97.+.5),sty=floor(vFac.y+.5),fh=vFac.z,bay=vFac.w,topH=vFac2.x,gH=vFac2.y;vec2 fu=vFU;
  if(vWN.y<.5){vec3 T=normalize(cross(vec3(0.,1.,0.),vWN));vec3 V=normalize(vWP2-cameraPosition);vec3 vt=vec3(dot(V,T),V.y,-dot(V,vWN));
   float shop=(gH>.1&&fu.y<gH)?1.:0.;float cw=shop>.5?5.6:bay,ch=shop>.5?gH:fh,y0=shop>.5?0.:gH;
   vec2 cell=vec2(floor(fu.x/cw),floor((fu.y-y0)/ch)),f=vec2(fract(fu.x/cw),fract((fu.y-y0)/ch));
   vec4 wr=shop>.5?vec4(.05,.07,.95,.76):sty<.5?vec4(.1,.2,.9,.86):sty<1.5?vec4(.27,.2,.73,.82):sty<2.5?vec4(.012,.03,.988,.985):sty<3.5?vec4(.12,.62,.88,.86):vec4(.17,.24,.83,.8);
   frameC=(sty>.5&&sty<1.5)||sty>3.5?vec3(.82,.8,.76):vec3(.045);
   float h1=hash21(cell+seed*7.31);bool skip=sty>2.5&&sty<3.5&&shop<.5&&mod(cell.x,3.)>.5;
   bool valid=fu.y>.3&&fu.y<topH-.85&&(shop>.5||fu.y>gH+.2);
   if(valid&&!skip&&f.x>wr.x&&f.x<wr.z&&f.y>wr.y&&f.y<wr.w){
    vec2 fd=min(f-wr.xy,wr.zw-f)*vec2(cw,ch);float edge=min(fd.x,fd.y);frame=1.-smoothstep(.035,.065,edge);
    if(sty>1.5&&sty<2.5&&shop<.5){float m=abs(fract(fu.x/1.6)-.5)*1.6;frame=max(frame,1.-smoothstep(.022,.04,m));float tr=abs(f.y-.08)*ch;frame=max(frame,1.-smoothstep(.03,.05,tr));}
    else if(shop<.5){float mx=abs(f.x-(wr.x+wr.z)*.5)*cw;frame=max(frame,1.-smoothstep(.02,.04,mx));}
    else{float mx=abs(fract(f.x*2.)-.5)*cw*.5;frame=max(frame,1.-smoothstep(.03,.05,mx));}
    glass=1.-frame;
    float rw=cw*(wr.z-wr.x),rh=ch*(wr.w-wr.y),rdp=shop>.5?6.:4.5;
    vec3 o=vec3((f.x-wr.x)/(wr.z-wr.x),(f.y-wr.y)/(wr.w-wr.y),0.);vec3 rd=vec3(vt.x/rw,vt.y/rh,max(vt.z,.002)/rdp);
    if(sty>1.5&&sty<2.5&&shop<.5){rw=bay;o.x=fract(fu.x/bay);rd.x=vt.x/bay;}
    rd.x=(rd.x>=0.?1.:-1.)*max(abs(rd.x),1e-4);rd.y=(rd.y>=0.?1.:-1.)*max(abs(rd.y),1e-4);vec3 tt=vec3((rd.x>0.?1.-o.x:-o.x)/rd.x,(rd.y>0.?1.-o.y:-o.y)/rd.y,1./rd.z);
    float t=min(tt.x,min(tt.y,tt.z));vec3 hp=o+rd*t;float face=tt.z<=min(tt.x,tt.y)?2.:(tt.y<=tt.x?1.:0.);
    vec3 wallC=mix(vec3(.78,.72,.62),vec3(.6,.64,.68),hash21(cell+3.1+seed));if(hash21(cell+9.)>.8)wallC=vec3(.72,.55,.42);vec3 col;
    if(face>1.5){col=wallC;col*=mix(1.,.35,step(hp.y,.34)*step(.12,hp.x)*step(hp.x,.8));
     if(shop>.5){float shelf=step(.82,fract(hp.y*5.));float item=step(.35,hash21(floor(hp.xy*vec2(23.,5.))+cell));vec3 ic=mix(vec3(.85,.3,.18),vec3(.18,.45,.85),hash21(floor(hp.xy*vec2(23.,5.))+cell+1.));col=mix(vec3(.22,.2,.19),ic*.8,item*step(.1,hp.y)*step(hp.y,.82));col=mix(col,vec3(.55,.5,.45),shelf);}
     else if(hash21(cell+5.)>.6){col=mix(col,vec3(.15,.2,.3),step(abs(hp.x-.55),.18)*step(abs(hp.y-.62),.12));}}
    else if(face>.5){if(rd.y>0.){col=vec3(.9);col+=step(abs(fract(hp.x*2.)-.5),.2)*step(abs(hp.z-.45),.09)*1.6;}else col=shop>.5?mix(vec3(.5,.48,.45),vec3(.35,.33,.3),step(.5,fract(hp.x*4.+floor(hp.z*4.)*.5))):vec3(.32,.22,.15);}
    else{col=wallC*.7;if(shop>.5){float sh2=step(.82,fract(hp.y*5.));col=mix(vec3(.25,.22,.2),vec3(.6,.55,.5),sh2);col=mix(col,vec3(.7,.35,.25),step(.4,hash21(floor(hp.zy*vec2(9.,5.))+cell))*step(.1,hp.y)*step(hp.y,.8)*(1.-sh2)*.7);}}
    col*=.45+.55*(1.-hp.z*.6);
    float lit=shop>.5?step(.1,h1):step(sty>1.5&&sty<2.5?.76:.7,h1);
    vec3 lc=mix(vec3(1.,.74,.45),vec3(.8,.9,1.),step(.62,hash21(cell+7.7)));
    if(hash21(cell+11.)>.72&&shop<.5){float s=step(.4,fract(o.y*16.));float down=1.-hash21(cell+2.)*.85;col=mix(col,vec3(.85,.82,.72)*(.55+s*.45),step(down,o.y));}
    if(sty>.5&&sty<1.5&&shop<.5&&hash21(cell+4.)>.45){float cu=step(o.x,.2)+step(.8,o.x);col=mix(col,mix(vec3(.7,.2,.2),vec3(.85,.8,.6),hash21(cell+8.)),cu);}
    emitW=lit>.5?col*lc*(shop>.5?1.25:.95):col*vec3(.03,.032,.04);
    metalG=sty>1.5&&sty<2.5?.85:.25;}
   if(!valid&&gH>.1&&fu.y>gH-.05&&fu.y<gH+.35){frame=1.;frameC=vec3(.2,.19,.18);}
   diffuseColor.rgb*=mix(.62,1.,smoothstep(0.,1.6,fu.y));
   float corner=smoothstep(topH-1.2,topH,fu.y);diffuseColor.rgb*=1.-corner*.15;}}
 diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.012,.014,.016),glass);diffuseColor.rgb=mix(diffuseColor.rgb,frameC,frame);`;
function facadeMat(name,meters,o={}){const m=pbr(name,meters,Object.assign({env:.85},o));m.vertexColors=true;
 m.onBeforeCompile=sh=>{sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\n'+FACV).replace('#include <fog_vertex>','#include <fog_vertex>\nvFac=fac;vFac2=fac2;vFU=uv;vWP2=(modelMatrix*vec4(transformed,1.)).xyz;vWN=normalize(mat3(modelMatrix)*objectNormal);');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\n'+FACF).replace('#include <map_fragment>',FACMAIN)
   .replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor=mix(roughnessFactor,.025,glass);roughnessFactor=mix(roughnessFactor,.45,frame);')
   .replace('#include <metalnessmap_fragment>','#include <metalnessmap_fragment>\nmetalnessFactor=mix(metalnessFactor,metalG,glass);metalnessFactor=mix(metalnessFactor,.5,frame);')
   .replace('#include <normal_fragment_maps>','#include <normal_fragment_maps>\nnormal=normalize(mix(normal,normalize(vNormal),max(glass,frame)));')
   .replace('#include <emissivemap_fragment>','#include <emissivemap_fragment>\n{vec3 Vv=normalize(cameraPosition-vWP2);float fr=pow(1.-clamp(dot(Vv,vWN),0.,1.),4.);totalEmissiveRadiance+=emitW*(1.-fr*.85)*(1.-metalG*.55);}');};
 m.customProgramCacheKey=()=>'facade';return m;}
/* ---- materials ---- */
const MAT={};
function initMaterials(){
 MAT.asphalt=makeWet(pbr('asphalt',7,{rough:1,rmap:1,ns:1.2,env:.7}),{tint:1});
 MAT.sidewalk=makeWet(pbr('sidewalk',3.2,{rough:.95,env:.5}),{wet:.75});
 MAT.plaza=makeWet(pbr('plaza',3,{rough:.8,env:.6}),{wet:.6});
 MAT.curb=pbr('concrete',2,{color:0xb8b3aa,rough:.85});
 MAT.sand=pbr('sand',4,{rough:1,env:.3});MAT.grass=pbr('grass',4,{rough:1,env:.25});
 MAT.wetsand=makeWet(pbr('sand',4,{rough:.7,env:.6,color:0x9a8670}),{wet:.9});
 MAT.planks=pbr('planks',3,{rough:.85});MAT.roof=pbr('roof_gravel',4,{rough:1,env:.3});MAT.roofClay=pbr('roof_clay',2.2,{rough:.85});
 MAT.trim=pbr('concrete',2.5,{color:0xd6d0c4,rough:.8});MAT.stone=pbr('stone_light',3,{rough:.75});MAT.darkMetal=new THREE.MeshStandardMaterial({color:lin(0x26282b),roughness:.45,metalness:.8});
 MAT.metal=new THREE.MeshStandardMaterial({color:lin(0x9aa0a6),roughness:.35,metalness:.85});MAT.whiteMetal=new THREE.MeshStandardMaterial({color:lin(0xe8e8e6),roughness:.4,metalness:.3});
 MAT.wood=new THREE.MeshStandardMaterial({color:lin(0x6a4a32),roughness:.8});MAT.glassDark=new THREE.MeshStandardMaterial({color:0x080a0c,roughness:.05,metalness:.9});
 MAT.container=pbr('container',2.5,{rough:.6,metal:.4,extra:{vertexColors:true}});MAT.corrugated=pbr('corrugated',2,{rough:.55,metal:.6});MAT.shutter=pbr('shutter',2.5,{rough:.5,metal:.6,color:0x9aa0a6});
 MAT.water=makeWater();
 const F={};MAT.fac=F;
 F.brick_red=facadeMat('brick_red',2.4);F.brick_dark=facadeMat('brick_dark',2.4);F.brick_orange=facadeMat('brick_orange',2.4);F.brick_tan=facadeMat('brick_tan',2.4);F.brick_factory=facadeMat('brick_factory',3);
 F.stucco=facadeMat('stucco',2.5,{rough:.9});F.plaster=facadeMat('plaster',2.5,{rough:.92});F.concrete=facadeMat('concrete',3.5,{rough:.85});F.panels=facadeMat('panels',4,{rough:.8});
 F.tiles=facadeMat('tiles_dark',3,{rough:.6});F.stone_dark=facadeMat('stone_dark',3.5,{rough:.8});F.stone_light=facadeMat('stone_light',3.5,{rough:.8});F.corrugated=facadeMat('corrugated',2.4,{rough:.5,metal:.5});}
function makeWater(){const m=new THREE.MeshStandardMaterial({color:lin(0x0d3a46),roughness:.06,metalness:0,envMapIntensity:1.2,normalMap:T('sand','n',1/40),normalScale:new THREE.Vector2(.3,.3)});
 m.onBeforeCompile=sh=>{Object.assign(sh.uniforms,REFL.uniforms);sh.uniforms.uT=WATERT;
  sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vWP;varying vec4 vRU;uniform mat4 reflMat;uniform float uT;').replace('#include <begin_vertex>','#include <begin_vertex>\nvec4 w0=modelMatrix*vec4(transformed,1.);float wv=sin(w0.x*.12+uT*1.3)*.25+sin(w0.z*.09-uT*.9+w0.x*.05)*.18;transformed.z+=wv;')
   .replace('#include <fog_vertex>','#include <fog_vertex>\nvec4 wp4=modelMatrix*vec4(transformed,1.);vWP=wp4.xyz;vRU=reflMat*wp4;');
  sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vWP;varying vec4 vRU;uniform sampler2D tRefl;uniform float reflOn;uniform float uT;'+WETCODE)
   .replace('#include <normal_fragment_maps>',`vec2 wq=vWP.xz;vec2 sp1=vec2(uT*.35,uT*.2),sp2=vec2(uT*.6,uT*.1);float wa=fbm2(wq*.35+sp1),wb=fbm2(wq*.35+vec2(.6,0.)+sp1),wc=fbm2(wq*.35+vec2(0.,.6)+sp1);
    float wd=fbm2(wq*1.7-sp2),we=fbm2(wq*1.7+vec2(.15,0.)-sp2),wf=fbm2(wq*1.7+vec2(0.,.15)-sp2);
    vec3 wn=normalize(vec3((wa-wb)*1.4+(wd-we)*.5,1.,(wa-wc)*1.4+(wd-wf)*.5));normal=normalize((viewMatrix*vec4(wn,0.)).xyz);`)
   .replace('#include <tonemapping_fragment>',`{vec3 V=normalize(cameraPosition-vWP);float fr=.02+.98*pow(1.-max(V.y,0.),5.);vec3 wn2=normalize((vec4(normal,0.)*viewMatrix).xyz);vec4 ru=vRU;ru.xy+=wn2.xz*.06*ru.w;
    if(reflOn>.5)gl_FragColor.rgb=mix(gl_FragColor.rgb,texture2DProj(tRefl,ru).rgb,clamp(fr*1.1,0.,.95));
    float shore=smoothstep(${(W+66).toFixed(1)},${(W+62).toFixed(1)},vWP.x);float fo=step(.62,fbm2(vWP.xz*.6+vec2(uT*.4,0.)))*shore;gl_FragColor.rgb+=vec3(.55,.5,.45)*fo*.6;}
    #include <tonemapping_fragment>`);};
 m.customProgramCacheKey=()=>'water';return m;}
const WATERT={value:0};
/* ---- geometry helpers ---- */
function setAttrs(g,tint,fac,fac2){const n=g.attributes.position.count;const c=new Float32Array(n*3),a=new Float32Array(n*4),b=new Float32Array(n*2);const col=lin(tint);for(let i=0;i<n;i++){c[i*3]=col.r;c[i*3+1]=col.g;c[i*3+2]=col.b;a.set(fac,i*4);b.set(fac2,i*2);}
 g.setAttribute('color',new THREE.BufferAttribute(c,3));g.setAttribute('fac',new THREE.BufferAttribute(a,4));g.setAttribute('fac2',new THREE.BufferAttribute(b,2));return g;}
/* 4 facade walls of a box (with window shader attributes) */
function facadeBox(mat,x0,x1,y0,y1,z0,z1,o){const w=x1-x0,d=z1-z0,h=y1-y0,cx=(x0+x1)/2,cy=(y0+y1)/2,cz=(z0+z1)/2;
 const fac=[o.seed==null?Math.random():o.seed,o.style||0,o.fh||3.4,o.bay||3],fac2=[o.top||y1,o.gH||0];let u=0;
 const fs=[[w,0,cx,z1,1],[d,Math.PI/2,x1,cz,0],[w,Math.PI,cx,z0,1],[d,-Math.PI/2,x0,cz,0]];
 for(const[fw,ry,px,pz,ax]of fs){const g=new THREE.PlaneGeometry(fw,h);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,u+uv.getX(i)*fw,y0+uv.getY(i)*h);u+=fw+.37;
  g.rotateY(ry);g.translate(ax?cx:px,cy,ax?pz:cz);if(o.M)g.applyMatrix4(o.M);setAttrs(g,o.tint||0xffffff,fac,fac2);addGeo(mat,g,true);}}
function plainBox(mat,x0,x1,y0,y1,z0,z1,o={}){const w=x1-x0,h=y1-y0,d=z1-z0;const g=new THREE.BoxGeometry(w,h,d);const uv=g.attributes.uv,nm=g.attributes.normal;
 if(o.uvm){for(let i=0;i<uv.count;i++){const ax=Math.abs(nm.getX(i))>.5?0:Math.abs(nm.getY(i))>.5?1:2;const fw=ax===0?d:w,fh=ax===1?d:h;uv.setXY(i,uv.getX(i)*fw/o.uvm,uv.getY(i)*fh/o.uvm);}}
 if(o.ry)g.rotateY(o.ry);g.translate((x0+x1)/2,(y0+y1)/2,(z0+z1)/2);if(o.M)g.applyMatrix4(o.M);if(o.tint)setColor(g,o.tint);addGeo(mat,g,o.shadow!==false,o.layer);return g;}
function setColor(g,hex){const n=g.attributes.position.count,c=new Float32Array(n*3),col=lin(hex);for(let i=0;i<n;i++){c[i*3]=col.r;c[i*3+1]=col.g;c[i*3+2]=col.b;}g.setAttribute('color',new THREE.BufferAttribute(c,3));}
function topQuad(mat,x0,x1,y,z0,z1,uvm,M,shadow){const g=new THREE.PlaneGeometry(x1-x0,z1-z0);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*(x1-x0)/uvm,uv.getY(i)*(z1-z0)/uvm);g.rotateX(-Math.PI/2);g.translate((x0+x1)/2,y,(z0+z1)/2);if(M)g.applyMatrix4(M);addGeo(mat,g,!!shadow);return g;}
function cyl(mat,x,y,z,r0,r1,h,seg=10,o={}){const g=new THREE.CylinderGeometry(r0,r1,h,seg,1,!!o.open);g.translate(x,y+h/2,z);if(o.M)g.applyMatrix4(o.M);addGeo(mat,g,o.shadow!==false);}
/* ---- sign atlas (shop names, hotel neon, billboards) ---- */
const ATLAS={c:null,g:null,n:0,cols:4,rows:16,mat:null,neon:null};
function atlasInit(){const[c,g]=cvs(2048,2048);ATLAS.c=c;ATLAS.g=g;g.fillStyle='#000';g.fillRect(0,0,2048,2048);}
function atlasSlot(draw){const i=ATLAS.n++;const cw=512,chh=128,x=(i%ATLAS.cols)*cw,y=Math.floor(i/ATLAS.cols)*chh;const g=ATLAS.g;g.save();g.beginPath();g.rect(x,y,cw,chh);g.clip();g.translate(x,y);draw(g,cw,chh);g.restore();return{u0:x/2048,u1:(x+cw)/2048,v0:1-(y+chh)/2048,v1:1-y/2048};}
function signQuad(slot,cx,cy,cz,w,h,ry,neon){const g=new THREE.PlaneGeometry(w,h);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,slot.u0+uv.getX(i)*(slot.u1-slot.u0),slot.v0+uv.getY(i)*(slot.v1-slot.v0));g.rotateY(ry);g.translate(cx,cy,cz);addGeo(neon?ATLAS.neon:ATLAS.mat,g,false);}
const SHOPS=[['CAFÉ ROMA','#2a1a12','#f3d9a4'],['PHARMACY','#0e5a3a','#ffffff'],['TACOS EL REY','#b8321a','#ffe08a'],['BARBER','#1a1a1a','#e8e8e8'],['PAWN · GOLD','#3a2a08','#ffd36e'],['DINER 24H','#8a1a1a','#ffffff'],['PIZZA NAPOLI','#1f4d2b','#fff3d0'],['LAUNDROMAT','#1d3d6b','#ffffff'],['BOOKS','#4a1d1d','#f2e2c2'],['ELECTRONICS','#111','#5ad1ff'],['NAIL STUDIO','#5a1d4a','#ffd0ec'],['DONUTS','#d86a9a','#ffffff'],['SUSHI ZEN','#151515','#ff5a4a'],['FLOWERS','#2e5a2a','#f8f0e0'],['SURF SHOP','#0a5a7a','#ffe066'],['GELATO','#e8e0d0','#b8321a'],['DELI','#1a3a2a','#f0e0b0'],['OPTICS','#e8e8e8','#1a3a6a'],['BAKERY','#6a3a1a','#ffe8c0'],['VINYL','#111','#ff9a2a'],['SHOES','#2a2a3a','#fff'],['WINE BAR','#3a0a1a','#f2c2a2'],['TATTOO','#0a0a0a','#e83a3a'],['MARKET','#c03a1a','#fff']];
let shopSlots=[];
function initSigns(){atlasInit();
 shopSlots=SHOPS.map(([n,bg,fg])=>atlasSlot((g,w,h)=>{g.fillStyle=bg;g.fillRect(0,0,w,h);g.strokeStyle='rgba(255,255,255,.15)';g.lineWidth=4;g.strokeRect(6,6,w-12,h-12);g.font=`${n.length>11?58:70}px Anton, Impact, sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillStyle=fg;g.shadowColor=fg;g.shadowBlur=8;g.fillText(n,w/2,h/2+4);}));
 const neon=(t,col)=>atlasSlot((g,w,h)=>{g.fillStyle='#000';g.fillRect(0,0,w,h);g.font=`italic ${t.length>9?66:80}px Anton, Impact, sans-serif`;g.textAlign='center';g.textBaseline='middle';g.lineWidth=4;g.strokeStyle=col;g.shadowColor=col;g.shadowBlur=24;g.strokeText(t,w/2,h/2+4);g.shadowBlur=8;g.fillStyle='#fff';g.fillText(t,w/2,h/2+4);});
 ATLAS.hotels=[['THE CARLYLE','#ff4fd8'],['SEA BREEZE','#4ff0ff'],['FLAMINGO','#ff5a8a'],['TIDES','#7aff6a'],['CORAL REEF','#ffb04f'],['MOONLIGHT','#a07aff'],['SUNSET INN','#ff7a3a'],['PALM COURT','#5affc0']].map(([t,c])=>neon(t,c));
 ATLAS.ads=[['VELVET COLA','#b8141c','#fff'],['SUNSET FM 104.5','#ff8a00','#1a0a40'],['FLY OCEANAIR','#0a6ab8','#fff'],['LUXE WATCHES','#111','#e8c66a'],['DR. SMILE','#2ab0a0','#fff'],['NOVA PHONE 9','#111','#7af']].map(([t,bg,fg])=>atlasSlot((g,w,h)=>{const gr=g.createLinearGradient(0,0,w,h);gr.addColorStop(0,bg);gr.addColorStop(1,'#000');g.fillStyle=gr;g.fillRect(0,0,w,h);g.font='72px Anton, Impact, sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle=fg;g.fillText(t,w/2,h/2+4);}));
 ATLAS.special={};
 for(const[k,t,bg,fg]of[['bank','BANK OF THE COAST','#1a140c','#e8c66a'],['hospital','ST. MARY HOSPITAL','#ffffff','#c0262a'],['police','POLICE DEPARTMENT','#0e2550','#ffffff'],['quik','QUIK MART 24/7','#c0262a','#ffffff'],['liquor','LIQUOR · BEER · WINE','#3a0a4a','#ff8af0'],['jewel','DIAMOND DISTRICT','#0c0c0c','#e8c66a'],['guns','LOCK & LOAD — GUNS','#2a3014','#ffe066'],['chop','PARTS & SALVAGE','#2a1a0a','#ff9a3a'],['spray','FRESH COAT · RESPRAY','#0a2a4a','#9fe8ff'],['er','EMERGENCY','#c0262a','#ffffff'],['docks','PORT OF ASPHALT','#14202a','#e0e6ea']])
  ATLAS.special[k]=atlasSlot((g,w,h)=>{g.fillStyle=bg;g.fillRect(0,0,w,h);g.font=`${t.length>16?50:64}px Anton, Impact, sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillStyle=fg;g.fillText(t,w/2,h/2+4);});
 const t=ctex(ATLAS.c);t.anisotropy=8;ATLAS.mat=new THREE.MeshStandardMaterial({map:t,emissiveMap:t,emissive:new THREE.Color(1.2,1.2,1.2),roughness:.5,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
 ATLAS.neon=new THREE.MeshBasicMaterial({map:t,color:new THREE.Color(2.6,2.6,2.6),transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3});}
/* ---- city layout ---- */
const blocks=[],places=[],LAMPS=[],TREES=[],PALMS=[],PROPSPOTS=[],STATIC=[],PARKED=[];
function districtOf(i,j){if(i>=6)return'beach';if(j>=6)return'docks';if(i<=2&&j>=3)return'suburb';if(i<=2)return'oldtown';if(i>=3&&i<=5&&j>=2&&j<=5)return'downtown';return'midtown';}
const SPECIAL={'4,4':{kind:'park'},'4,3':{kind:'bank',side:'S'},'5,1':{kind:'hospital',side:'W'},'2,2':{kind:'police',side:'E'},'1,1':{kind:'store',sign:'quik',side:'S'},'5,6':{kind:'store',sign:'liquor',side:'N'},'4,2':{kind:'jewelry',side:'S'},'3,6':{kind:'gunshop',side:'N'},'1,7':{kind:'chop',side:'N'},'6,2':{kind:'spray',side:'W'},'2,7':{kind:'court'},'0,4':{kind:'park'},'6,5':{kind:'plaza'}};
const SIDEANG={S:0,N:Math.PI,E:Math.PI/2,W:-Math.PI/2};
function sideFrame(B,side){const ix0=B.x0+SW,ix1=B.x1-SW,iz0=B.z0+SW,iz1=B.z1-SW,cx=(B.x0+B.x1)/2,cz=(B.z0+B.z1)/2;const p=side==='S'?[cx,iz1]:side==='N'?[cx,iz0]:side==='E'?[ix1,cz]:[ix0,cz];const M=new THREE.Matrix4().makeRotationY(SIDEANG[side]);M.setPosition(p[0],0,p[1]);return M;}
function lrect(M,u0,u1,v0,v1){const a=new V3(u0,0,-v0).applyMatrix4(M),b=new V3(u1,0,-v1).applyMatrix4(M);return{x0:Math.min(a.x,b.x),x1:Math.max(a.x,b.x),z0:Math.min(a.z,b.z),z1:Math.max(a.z,b.z)};}
const lpt=(M,u,v)=>new V3(u,0,-v).applyMatrix4(M);
const PASTEL=[0xf6c6c9,0xbfe6d8,0xf7e3a1,0xc7dcf2,0xffffff,0xf3d1b0,0xd8c8f0,0xa8e0e8];
const HOUSEC=[0xe8dcc4,0xd8c0a0,0xc4d4dc,0xf0e8d8,0xb8c8a8,0xe0c8b8,0xffffff];
/* which walls of a lot face a street (for signs/awnings) */
function streetSides(B,R){const s=[];if(R.z1>B.z1-SW-1.5)s.push('S');if(R.z0<B.z0+SW+1.5)s.push('N');if(R.x1>B.x1-SW-1.5)s.push('E');if(R.x0<B.x0+SW+1.5)s.push('W');return s;}
function shopDressing(B,R,gH){for(const sd of streetSides(B,R)){const along=sd==='S'||sd==='N';const L=along?R.x1-R.x0:R.z1-R.z0;const n=Math.max(1,Math.floor(L/11));
  for(let k=0;k<n;k++){const t=(k+.5)/n;const sl=spick(shopSlots);const w=Math.min(5,L/n-1),off=.08;
   let cx,cz,ry;if(sd==='S'){cx=R.x0+L*t;cz=R.z1+off;ry=0;}else if(sd==='N'){cx=R.x1-L*t;cz=R.z0-off;ry=Math.PI;}else if(sd==='E'){cx=R.x1+off;cz=R.z1-L*t;ry=Math.PI/2;}else{cx=R.x0-off;cz=R.z0+L*t;ry=-Math.PI/2;}
   signQuad(sl,cx,gH-.55,cz,w,w/4.2,ry,false);
   if(srnd()<.55){const g=new THREE.BoxGeometry(w+.4,.05,1.5);g.rotateX(.28);g.translate(0,gH-1.25,.72);g.rotateY(ry);g.translate(cx,0,cz);addGeo(spick(AWN),g,true);}}}}
let AWN=[];
function initAwnings(){AWN=['#9a2a2a','#2a5a3a','#2a3a6a','#b08a20','#e6e0d4','#222'].map(c=>{const[cv,g]=cvs(64,64);for(let i=0;i<8;i++){g.fillStyle=i%2?c:'#efe8da';g.fillRect(i*8,0,8,64);}return new THREE.MeshStandardMaterial({map:ctex(cv,1),roughness:.9});});}
function roofDressing(R,h,kind){const w=R.x1-R.x0,d=R.z1-R.z0;
 plainBox(MAT.trim,R.x0-.15,R.x1+.15,h,h+.75,R.z0-.15,R.z0+.2,{uvm:2});plainBox(MAT.trim,R.x0-.15,R.x1+.15,h,h+.75,R.z1-.2,R.z1+.15,{uvm:2});plainBox(MAT.trim,R.x0-.15,R.x0+.2,h,h+.75,R.z0,R.z1,{uvm:2});plainBox(MAT.trim,R.x1-.2,R.x1+.15,h,h+.75,R.z0,R.z1,{uvm:2});
 topQuad(MAT.roof,R.x0,R.x1,h+.05,R.z0,R.z1,4,null,false);
 for(let k=0,n=rint(1,4);k<n;k++){const sx=srange(1.2,2.6),sz=srange(1.2,2.6);if(w<sx*2+1||d<sz*2+1)continue;const x=srange(R.x0+sx+.5,R.x1-sx-.5),z=srange(R.z0+sz+.5,R.z1-sz-.5);plainBox(MAT.metal,x-sx/2,x+sx/2,h,h+srange(.9,1.6),z-sz/2,z+sz/2);}
 if(kind==='old'&&srnd()<.4&&w>9&&d>9){const x=srange(R.x0+3,R.x1-3),z=srange(R.z0+3,R.z1-3);cyl(MAT.wood,x,h+2.6,z,1.5,1.5,2.8,14);const cg=new THREE.ConeGeometry(1.65,1.1,14);cg.translate(x,h+5.95,z);addGeo(MAT.darkMetal,cg);for(const[a,b]of[[-1,-1],[1,-1],[1,1],[-1,1]])plainBox(MAT.darkMetal,x+a*1.05-.07,x+a*1.05+.07,h,h+2.6,z+b*1.05-.07,z+b*1.05+.07);}
 if(kind==='tower'&&srnd()<.5){const x=(R.x0+R.x1)/2,z=(R.z0+R.z1)/2;cyl(MAT.metal,x,h,z,.08,.15,srange(6,16),6);}
 if(srnd()<.12&&h>12&&h<50){const ad=spick(ATLAS.ads);const ax=srnd()<.5;const bx=(R.x0+R.x1)/2,bz=(R.z0+R.z1)/2;plainBox(MAT.darkMetal,bx-.15,bx+.15,h,h+4,bz-.15,bz+.15);signQuad(ad,bx+(ax?0:.2),h+6,bz+(ax?.2:0),12,3,ax?0:Math.PI/2,false);signQuad(ad,bx-(ax?0:.2),h+6,bz-(ax?.2:0),12,3,ax?Math.PI:-Math.PI/2,false);}}
function fireEscape(B,R,h,fh){const sd=streetSides(B,R);if(!sd.length)return;const s=sd[0];const along=s==='S'||s==='N';const L=along?R.x1-R.x0:R.z1-R.z0;if(L<8)return;const c=along?(R.x0+R.x1)/2:(R.z0+R.z1)/2;const off=s==='S'?R.z1:s==='N'?R.z0:s==='E'?R.x1:R.x0,sg=s==='S'||s==='E'?1:-1;
 for(let y=4.6+fh;y<h-1;y+=fh){const a=c-2,b=c+2,o0=off,o1=off+sg*1.1;const box=(u0,u1,y0,y1,v0,v1)=>along?plainBox(MAT.darkMetal,Math.min(u0,u1),Math.max(u0,u1),y0,y1,Math.min(v0,v1),Math.max(v0,v1)):plainBox(MAT.darkMetal,Math.min(v0,v1),Math.max(v0,v1),y0,y1,Math.min(u0,u1),Math.max(u0,u1));
  box(a,b,y,y+.06,o0,o1);box(a,b,y+.95,y+1,o1-sg*.04,o1);box(a,a+.05,y,y+1,o0,o1);box(b-.05,b,y,y+1,o0,o1);
  const g=new THREE.BoxGeometry(along?3.6:.5,.05,along?.5:3.6);const ang=Math.atan2(fh,3.4);if(along)g.rotateZ(ang);else g.rotateX(-ang);g.translate(along?c:off+sg*.8,y-fh/2,along?off+sg*.8:c);addGeo(MAT.darkMetal,g,true);}}
function building(B,R,h,o){const st=o.style;const gH=o.shops?4.4:0;facadeBox(o.mat,R.x0,R.x1,.15,h,R.z0,R.z1,{style:st,fh:o.fh||3.4,bay:o.bay||3,gH,tint:o.tint||0xffffff,top:h,seed:srnd()});
 if(o.shops){shopDressing(B,R,gH);plainBox(MAT.trim,R.x0-.12,R.x1+.12,gH,gH+.32,R.z0-.12,R.z1+.12,{uvm:2});}
 if(o.cornice){plainBox(MAT.trim,R.x0-.35,R.x1+.35,h-.9,h-.55,R.z0-.35,R.z1+.35,{uvm:2});}
 roofDressing(R,h,o.kind);B.bld.push({x0:R.x0,x1:R.x1,z0:R.z0,z1:R.z1,h});}
function splitLots(R,minW){const w=R.x1-R.x0,d=R.z1-R.z0;let lots=[[R.x0,R.x1,R.z0,R.z1]];
 const cut=(arr,ax)=>{const out=[];for(const L of arr){const len=ax?L[1]-L[0]:L[3]-L[2];if(len<minW*2+1){out.push(L);continue;}const m=(ax?L[0]:L[2])+len*srange(.38,.62);if(ax)out.push([L[0],m-.4,L[2],L[3]],[m+.4,L[1],L[2],L[3]]);else out.push([L[0],L[1],L[2],m-.4],[L[0],L[1],m+.4,L[3]]);}return out;};
 lots=cut(lots,1);lots=cut(lots,0);if(srnd()<.5)lots=cut(lots,1);return lots.map(L=>({x0:L[0],x1:L[1],z0:L[2],z1:L[3]}));}
const FACLIST={oldtown:['brick_red','brick_dark','brick_orange','brick_tan','brick_red'],midtown:['concrete','plaster','brick_tan','stucco','panels','stone_light'],downtown:['tiles','stone_dark','panels','concrete','stone_light'],docks:['brick_factory','corrugated','concrete'],beach:['stucco','stucco','plaster']};
function fillDistrict(B,R,dist){const cx=(B.x0+B.x1)/2,cz=(B.z0+B.z1)/2,dc=Math.hypot(cx-W*.55,cz-W*.45);
 if(dist==='suburb'){houses(B,R);return;}
 if(dist==='docks'){warehouses(B,R);return;}
 const lots=splitLots(R,dist==='downtown'?14:dist==='beach'?10:9);
 for(const L0 of lots){const L={x0:L0.x0+srange(0,.6),x1:L0.x1-srange(0,.6),z0:L0.z0+srange(0,.6),z1:L0.z1-srange(0,.6)};
  if(dist==='oldtown'){const fh=3.3,fl=rint(4,7);building(B,L,4.4+fl*fh,{mat:MAT.fac[spick(FACLIST.oldtown)],style:1,fh,bay:2.6,shops:true,cornice:true,kind:'old'});if(srnd()<.6)fireEscape(B,L,4.4+fl*fh,fh);}
  else if(dist==='beach'){const fh=3.2,fl=rint(2,5),h=4.4+fl*fh,tint=spick(PASTEL);building(B,L,h,{mat:MAT.fac.stucco,style:4,fh,bay:3.2,shops:true,tint,kind:'deco'});
   for(let y=4.4+fh;y<h-.5;y+=fh)plainBox(MAT.whiteMetal,L.x0-.18,L.x1+.18,y-.12,y,L.z0-.18,L.z1+.18);
   const sd=streetSides(B,L);if(sd.length&&srnd()<.85){const s=sd[0],hs=spick(ATLAS.hotels),y=h*.62;const fx=s==='E'?L.x1+.6:s==='W'?L.x0-.6:(L.x0+L.x1)/2,fz=s==='S'?L.z1+.6:s==='N'?L.z0-.6:(L.z0+L.z1)/2;
    const ry=s==='S'||s==='N'?Math.PI/2:0;plainBox(MAT.whiteMetal,fx-(ry?1.1:.18),fx+(ry?1.1:.18),4.6,h+1.2,fz-(ry?.18:1.1),fz+(ry?.18:1.1),{ry:0});
    const L2=Math.min(h-5.5,9);for(const sg of[1,-1]){const g=new THREE.PlaneGeometry(L2,L2/4);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,hs.u0+uv.getX(i)*(hs.u1-hs.u0),hs.v0+uv.getY(i)*(hs.v1-hs.v0));g.rotateZ(Math.PI/2);g.rotateY((s==='S'||s==='N')?(sg>0?0:Math.PI):(sg>0?Math.PI/2:-Math.PI/2));
     g.translate(fx+((s==='E'||s==='W')?sg*.19:0),4.6+(h-3.4)/2,fz+((s==='S'||s==='N')?sg*.19:0));addGeo(ATLAS.neon,g,false);}}}
  else if(dist==='downtown'){const tall=dc<170?srange(.6,1):srange(.3,.7);const podium=8.8,fh=3.8,h=Math.round(podium+tall*srange(60,140)/fh)*fh;
   building(B,L,podium,{mat:MAT.fac.stone_dark,style:0,fh:4.4,bay:4,shops:true,kind:'tower'});
   const ix=(L.x1-L.x0)*srange(.06,.16),iz=(L.z1-L.z0)*srange(.06,.16),T2={x0:L.x0+ix,x1:L.x1-ix,z0:L.z0+iz,z1:L.z1-iz};const mat=MAT.fac[spick(FACLIST.downtown)];
   facadeBox(mat,T2.x0,T2.x1,podium,h,T2.z0,T2.z1,{style:srnd()<.6?2:0,fh,bay:srnd()<.5?1.6:3.2,top:h,tint:spick([0xffffff,0xdfe6ee,0xf2e8dc]),seed:srnd()});roofDressing(T2,h,'tower');
   if(h>70&&srnd()<.6){const k=.18;const T3={x0:T2.x0+(T2.x1-T2.x0)*k,x1:T2.x1-(T2.x1-T2.x0)*k,z0:T2.z0+(T2.z1-T2.z0)*k,z1:T2.z1-(T2.z1-T2.z0)*k},h3=h+srange(10,26);facadeBox(mat,T3.x0,T3.x1,h+.75,h3,T3.z0,T3.z1,{style:2,fh,bay:1.6,top:h3,seed:srnd()});roofDressing(T3,h3,'tower');}
   B.bld[B.bld.length-1].h=h;}
  else{const fh=3.4,fl=rint(3,12),h=4.4+fl*fh;building(B,L,h,{mat:MAT.fac[spick(FACLIST.midtown)],style:srnd()<.5?0:1,fh,bay:srnd()<.5?3:2.7,shops:true,cornice:srnd()<.4,tint:spick([0xffffff,0xf0e6d8,0xe0e4e8,0xe8d8c8]),kind:'mid'});}}}
function houses(B,R){const lots=[];const per=3;for(const side of['N','S']){for(let k=0;k<per;k++){const w=(R.x1-R.x0)/per;const x0=R.x0+k*w+1.2,x1=x0+w-2.4;const z0=side==='N'?R.z0+5:R.z1-14,z1=z0+9;lots.push({x0,x1,z0,z1,side});}}
 topQuad(MAT.grass,R.x0,R.x1,.16,R.z0,R.z1,4,null,false);
 for(const L of lots){const tint=spick(HOUSEC),h=srnd()<.5?6.4:3.4;facadeBox(MAT.fac.plaster,L.x0,L.x1,.15,h,L.z0,L.z1,{style:1,fh:3.2,bay:2.8,tint,top:h+.6,seed:srnd()});
  const w=L.x1-L.x0,d=L.z1-L.z0,rh=d*.42;const sh=new THREE.Shape();sh.moveTo(-d/2-.5,0);sh.lineTo(d/2+.5,0);sh.lineTo(0,rh);sh.lineTo(-d/2-.5,0);const g=new THREE.ExtrudeGeometry(sh,{depth:w+.8,bevelEnabled:false});
  const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)/2.2,uv.getY(i)/2.2);g.rotateY(Math.PI/2);g.translate(L.x0-.4,h,(L.z0+L.z1)/2);addGeo(MAT.roofClay,g,true);
  const fz=L.side==='N'?L.z0-.05:L.z1+.05;plainBox(MAT.wood,(L.x0+L.x1)/2-.55,(L.x0+L.x1)/2+.55,.15,2.3,fz-.06,fz+.06);
  B.bld.push({x0:L.x0,x1:L.x1,z0:L.z0,z1:L.z1,h:h+rh});
  const hz0=L.side==='N'?R.z0+.2:R.z1-.5;for(let x=L.x0-1;x<L.x1+1;x+=.6)plainBox(MAT.whiteMetal,x,x+.08,.15,1.1,hz0,hz0+.08,{shadow:false});plainBox(MAT.whiteMetal,L.x0-1,L.x1+1,.85,.95,hz0,hz0+.08,{shadow:false});

  TREES.push([L.x0-1.5,L.side==='N'?R.z0+2.5:R.z1-2.5,srange(.8,1.1)]);}}
function warehouses(B,R){const lots=splitLots(R,16);for(const L of lots){const h=srange(8,14);const mat=srnd()<.5?MAT.fac.corrugated:MAT.fac.brick_factory;facadeBox(mat,L.x0,L.x1,.15,h,L.z0,L.z1,{style:3,fh:h,bay:4,top:h,tint:mat===MAT.fac.corrugated?spick([0x9aa4ac,0x6a7a6a,0xb0a080,0x8a5040,0x5a6a8a]):0xffffff,seed:srnd()});
  roofDressing(L,h,'ware');B.bld.push({x0:L.x0,x1:L.x1,z0:L.z0,z1:L.z1,h});
  for(const sd of streetSides(B,L)){const along=sd==='S'||sd==='N';const c=along?(L.x0+L.x1)/2:(L.z0+L.z1)/2;const off=sd==='S'?L.z1+.03:sd==='N'?L.z0-.03:sd==='E'?L.x1+.03:L.x0-.03;const g=new THREE.PlaneGeometry(5,4.5);g.rotateY(SIDEANG[sd]);g.translate(along?c:off,2.4,along?off:c);addGeo(MAT.shutter,g,false);}}}
function containers(x0,x1,z0,z1){const cols=[0xb03a2a,0x2a5a9a,0x2a7a4a,0xd8a02a,0x7a7a7a,0xe8e8e8,0x6a2a6a,0xd86a2a];for(let x=x0;x<x1-6.2;x+=6.5)for(let z=z0;z<z1-2.5;z+=2.7){const st=rint(1,3);for(let k=0;k<st;k++){if(srnd()<.15)continue;const g=plainBox(MAT.container,x,x+6.06,k*2.6,k*2.6+2.59,z,z+2.44,{uvm:2.5,tint:spick(cols)});}STATIC.push({x0:x,x1:x+6.06,z0:z,z1:z+2.44,h:st*2.6});}}
/* ---- landmarks ---- */
function special(B,sp){const side=sp.side||'S',M=sideFrame(B,side);const door=lpt(M,0,-1.8);let pl=null;const ang=SIDEANG[side];
 const sign=(slot,u,y,v,w,h)=>{const p=lpt(M,u,v);signQuad(slot,p.x,y,p.z,w,h,ang,false);};
 const fillRest=(u0,u1,v0)=>{fillDistrict(B,lrect(M,-23.8,u0-1,0,v0),districtOf(B.i,B.j));fillDistrict(B,lrect(M,u1+1,23.8,0,v0),districtOf(B.i,B.j));fillDistrict(B,lrect(M,-23.8,23.8,v0+1,48),districtOf(B.i,B.j));};
 const fb=(mat,u0,u1,y0,y1,v0,v1,o)=>{const R=lrect(M,u0,u1,v0,v1);facadeBox(mat,R.x0,R.x1,y0,y1,R.z0,R.z1,Object.assign({top:y1,seed:srnd()},o));return R;};
 const pb=(mat,u0,u1,y0,y1,v0,v1,o)=>{const R=lrect(M,u0,u1,v0,v1);plainBox(mat,R.x0,R.x1,y0,y1,R.z0,R.z1,o||{uvm:3});return R;};
 if(sp.kind==='bank'){pb(MAT.stone,-19,19,.15,1.1,-.2,7);pb(MAT.stone,-18,18,1.1,1.8,1.2,7);
  const R=fb(MAT.fac.stone_light,-19,19,.15,16,7,34,{style:0,fh:5,bay:4.2});roofDressing(R,16,'mid');
  for(let k=0;k<6;k++){const p=lpt(M,-13.5+k*5.4,4);cyl(MAT.stone,p.x,1.8,p.z,.82,.92,11.4,16);const p2=lpt(M,-13.5+k*5.4,4);plainBox(MAT.stone,p2.x-1.1,p2.x+1.1,13.2,13.6,p2.z-1.1,p2.z+1.1);}
  pb(MAT.stone,-18.5,18.5,13.6,15.4,1.6,7.4);const sh=new THREE.Shape();sh.moveTo(-18.5,0);sh.lineTo(18.5,0);sh.lineTo(0,4);sh.lineTo(-18.5,0);const g=new THREE.ExtrudeGeometry(sh,{depth:5.8,bevelEnabled:false});const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)/3,uv.getY(i)/3);g.translate(0,15.4,-7.4);g.applyMatrix4(M);addGeo(MAT.stone,g,true);
  sign(ATLAS.special.bank,0,14.5,1.55,24,2.2);
  const T2=fb(MAT.fac.tiles,-15,15,16,92,34,46,{style:2,fh:3.8,bay:1.6});roofDressing(T2,92,'tower');
  B.bld.push(lrect(M,-19,19,1.2,46));pl={kind:'bank',name:'BANK OF THE COAST',time:16,cash:[5000,9000],heat:110,heat2:120};}
 else if(sp.kind==='hospital'){const R=fb(MAT.fac.stucco,-21,21,.15,22,5,40,{style:0,fh:4,bay:3.6,gH:0,tint:0xf4f4f2});roofDressing(R,22,'mid');const T2=fb(MAT.fac.panels,-12,12,22.6,46,14,36,{style:2,fh:4,bay:1.6,tint:0xe8eef2});roofDressing(T2,46,'tower');
  const hp=lpt(M,0,25);cyl(new THREE.MeshStandardMaterial({color:lin(0x2a6a3a),roughness:.8}),hp.x,46.7,hp.z,7,7,.15,32);
  pb(MAT.whiteMetal,-8,8,4,4.4,-.5,5);for(const u of[-7.5,7.5]){const p=lpt(M,u,0);cyl(MAT.metal,p.x,0,p.z,.12,.12,4,8);}
  sign(ATLAS.special.hospital,0,8.5,4.95,18,2.2);sign(ATLAS.special.er,0,4.7,-.52,7,1.1);
  B.bld.push(lrect(M,-21,21,5,40));fillDistrict(B,lrect(M,-23.8,23.8,41,48),'midtown');pl={kind:'hospital',name:'HOSPITAL'};}
 else if(sp.kind==='police'){const R=fb(MAT.fac.brick_dark,-19,19,.15,15,4,32,{style:0,fh:3.6,bay:3.4,gH:0});roofDressing(R,15,'mid');pb(new THREE.MeshStandardMaterial({color:lin(0x1c3f94),roughness:.6}),-19.2,19.2,4,4.6,3.8,32.2);
  sign(ATLAS.special.police,0,7,3.75,16,2);const fp=lpt(M,14,1);cyl(MAT.metal,fp.x,0,fp.z,.08,.1,13,8);
  B.bld.push(lrect(M,-19,19,4,32));fillDistrict(B,lrect(M,-23.8,23.8,33,48),'oldtown');pl={kind:'police',name:'POLICE'};}
 else if(sp.kind==='store'||sp.kind==='jewelry'||sp.kind==='gunshop'){const key=sp.kind==='jewelry'?'jewel':sp.kind==='gunshop'?'guns':sp.sign;
  const R=fb(sp.kind==='jewelry'?MAT.fac.stone_dark:MAT.fac.brick_tan,-9,9,.15,5.4,0,14,{style:0,fh:5,bay:4,gH:4.4});roofDressing(R,5.4,'mid');sign(ATLAS.special[key],0,4.9,-.06,14,1.4);
  B.bld.push(R);fillRest(-9,9,15);
  pl=sp.kind==='gunshop'?{kind:'gunshop',name:'LOCK & LOAD'}:{kind:'store',name:sp.kind==='jewelry'?'DIAMOND DISTRICT':(key==='quik'?'QUIK MART':'LIQUOR'),time:sp.kind==='jewelry'?10:7,cash:sp.kind==='jewelry'?[1500,2600]:[300,750],heat:sp.kind==='jewelry'?75:45};}
 else if(sp.kind==='chop'||sp.kind==='spray'){const R=fb(sp.kind==='chop'?MAT.fac.corrugated:MAT.fac.plaster,-11,11,.15,8,0,18,{style:3,fh:8,bay:5,tint:sp.kind==='chop'?0x8a6a50:0xdde6ee});roofDressing(R,8,'ware');
  const p=lpt(M,0,-.04);const g=new THREE.PlaneGeometry(9,5.5);g.rotateY(ang);g.translate(p.x,2.9,p.z);addGeo(MAT.shutter,g,false);sign(ATLAS.special[sp.kind],0,6.8,-.08,15,1.5);
  B.bld.push(R);fillRest(-11,11,19);const rp=lpt(M,0,-SW-5.5);pl={kind:sp.kind,name:sp.kind==='chop'?'PARTS & SALVAGE':'FRESH COAT',road:{x:rp.x,z:rp.z}};}
 else if(sp.kind==='court'){const ix0=B.x0+SW,ix1=B.x1-SW,iz0=B.z0+SW,iz1=B.z1-SW;const cx=(ix0+ix1)/2,cz=(iz0+iz1)/2;
  const[c,g]=cvs(512,512);g.fillStyle='#3a5a6a';g.fillRect(0,0,512,512);g.fillStyle='#a8522a';g.fillRect(40,90,432,332);g.strokeStyle='#eee';g.lineWidth=5;g.strokeRect(40,90,432,332);g.beginPath();g.moveTo(256,90);g.lineTo(256,422);g.stroke();g.beginPath();g.arc(256,256,50,0,7);g.stroke();g.strokeRect(40,196,90,120);g.strokeRect(382,196,90,120);
  for(let i=0;i<3000;i++){g.fillStyle=`rgba(0,0,0,${Math.random()*.08})`;g.fillRect(Math.random()*512,Math.random()*512,3,3);}g.font='bold 60px Anton, Impact';g.fillStyle='rgba(30,140,60,.85)';g.fillText('EASTSIDE',150,70);
  topQuad(makeWet(new THREE.MeshStandardMaterial({map:ctex(c),roughness:.7}),{wet:.6}),ix0,ix1,.17,iz0,iz1,ix1-ix0,null,false);
  for(const s of[-1,1]){const hx=cx+s*17.5;cyl(MAT.metal,hx,0,cz,.1,.1,3.9,8);plainBox(MAT.whiteMetal,hx-s*.35-.05,hx-s*.35+.05,3.1,4.2,cz-.9,cz+.9);}
  for(const[a,b,c2,d]of[[ix0,ix1,iz0,iz0],[ix0,ix1,iz1,iz1],[ix0,ix0,iz0,iz1],[ix1,ix1,iz0,iz1]])plainBox(MAT.darkMetal,Math.min(a,b)-.04,Math.max(a,b)+.04,0,3,Math.min(c2,d)-.04,Math.max(c2,d)+.04,{shadow:false});
  containers(ix0+1,ix1-1,iz1-8,iz1-1);B.gang={x:cx,z:cz-4};}
 else if(sp.kind==='plaza'){topQuad(MAT.plaza,B.x0+SW,B.x1-SW,.17,B.z0+SW,B.z1-SW,3,null,false);const cx=(B.x0+B.x1)/2,cz=(B.z0+B.z1)/2;cyl(MAT.stone,cx,.15,cz,5,5.3,.7,32);cyl(MAT.water,cx,.15,cz,4.6,4.6,.62,32,{shadow:false});cyl(MAT.stone,cx,.15,cz,.6,.8,3,12);
  for(let k=0;k<10;k++){const a=k/10*Math.PI*2;PALMS.push([cx+Math.cos(a)*14,cz+Math.sin(a)*14,srange(.9,1.2)]);}}
 if(pl){pl.door={x:door.x,z:door.z};pl.cd=0;pl.side=side;places.push(pl);}}
function park(B){const ix0=B.x0+SW,ix1=B.x1-SW,iz0=B.z0+SW,iz1=B.z1-SW,cx=(ix0+ix1)/2,cz=(iz0+iz1)/2;topQuad(MAT.grass,ix0,ix1,.17,iz0,iz1,4,null,false);
 for(const ax of[0,1]){const g=new THREE.PlaneGeometry(ax?3:ix1-ix0,ax?iz1-iz0:3);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*(ax?3:ix1-ix0)/3,uv.getY(i)*(ax?iz1-iz0:3)/3);g.rotateX(-Math.PI/2);g.translate(cx,.19,cz);addGeo(MAT.plaza,g,false);}
 cyl(MAT.stone,cx,.15,cz,4.3,4.6,.65,28);cyl(MAT.water,cx,.15,cz,3.9,3.9,.58,28,{shadow:false});cyl(MAT.stone,cx,.15,cz,.5,.7,2.4,10);cyl(MAT.stone,cx,2.5,cz,1.5,.4,.4,14);
 for(let k=0;k<22;k++){const tx=srange(ix0+2,ix1-2),tz=srange(iz0+2,iz1-2);if(Math.abs(tx-cx)<3.5||Math.abs(tz-cz)<3.5)continue;TREES.push([tx,tz,srange(.9,1.4)]);}
 for(const[a,b,r]of[[cx-7,cz+2.2,0],[cx+7,cz-2.2,Math.PI],[cx+2.2,cz+7,Math.PI/2],[cx-2.2,cz-7,-Math.PI/2]])PROPSPOTS.push({type:'bench',x:a,z:b,ry:r});}
/* ---- street furniture placement ---- */
function streetProps(B){const{x0,x1,z0,z1}=B;const dist=districtOf(B.i,B.j);
 for(const[sx,sz]of[[-1,-1],[1,-1],[1,1],[-1,1]])LAMPS.push({x:sx<0?x0+.6:x1-.6,z:sz<0?z0+.6:z1-.6,ry:Math.atan2(-sx,-sz)});
 for(const e of[0,1,2,3]){const len=48;for(let t=16;t<len-12;t+=16){const p=e===0?[x0+t,z0+.6,Math.PI]:e===1?[x1-.6,z0+t,Math.PI/2]:e===2?[x0+t,z1-.6,0]:[x0+.6,z0+t,-Math.PI/2];if(srnd()<.55)LAMPS.push({x:p[0],z:p[1],ry:p[2]+Math.PI,mid:1});}}
 const sideP=(e,t,o)=>e===0?[x0+t,z0+o]:e===1?[x1-o,z0+t]:e===2?[x0+t,z1-o]:[x0+o,z0+t];
 const kinds=dist==='docks'?['barrel','barrel','cone','bin','hydrant']:dist==='suburb'?['bin','hydrant','mailbox']:['hydrant','bin','news','meter','meter','bench','bollard','bin'];
 for(let k=0;k<(dist==='suburb'?3:9);k++){const e=rint(0,3),t=srange(7,41),[px,pz]=sideP(e,t,srange(.5,.9));PROPSPOTS.push({type:spick(kinds),x:px,z:pz,ry:[Math.PI,Math.PI/2,0,-Math.PI/2][e]});}
 if(dist==='beach'||B.j===4)for(let t=8;t<44;t+=9){if(dist==='beach'){PALMS.push([x1-1.3,z0+t,srange(.85,1.2)]);PALMS.push([x0+1.3,z0+t,srange(.85,1.2)]);}else PALMS.push([x0+t,z0+1.3,srange(.85,1.2)]);}
 else if(dist!=='docks'&&dist!=='suburb')for(const e of[0,1,2,3])for(let t=9;t<44;t+=13)if(srnd()<.45){const[px,pz]=sideP(e,t,1.4);TREES.push([px,pz,srange(.65,.9)]);}}
function buildCity(){SEED=4242;initMaterials();initAwnings();initSigns();
 const asph=new THREE.Mesh(new THREE.PlaneGeometry(S+40,S+40),MAT.asphalt);asph.rotation.x=-Math.PI/2;asph.position.set(W/2,0,W/2);asph.receiveShadow=true;scene.add(asph);
 {const uv=asph.geometry.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*(S+40)/7,uv.getY(i)*(S+40)/7);MAT.asphalt.map.repeat.set(1,1);MAT.asphalt.normalMap.repeat.set(1,1);MAT.asphalt.roughnessMap.repeat.set(1,1);}
 for(let i=0;i<N;i++)for(let j=0;j<N;j++){const x0=i*CELL+HALF,x1=(i+1)*CELL-HALF,z0=j*CELL+HALF,z1=(j+1)*CELL-HALF;const B={i,j,x0,x1,z0,z1,bld:[],park:false,dist:districtOf(i,j)};blocks.push(B);
  {const g=new THREE.PlaneGeometry(x1-x0,z1-z0);const uv=g.attributes.uv;for(let k=0;k<uv.count;k++)uv.setXY(k,uv.getX(k)*(x1-x0)/3.2,uv.getY(k)*(z1-z0)/3.2);g.rotateX(-Math.PI/2);g.translate((x0+x1)/2,.15,(z0+z1)/2);addGeo(MAT.sidewalk,g,false);}
  for(const[a,b,c,d,ry]of[[x0,x1,z1,z1,0],[x0,x1,z0,z0,Math.PI],[x1,x1,z0,z1,Math.PI/2],[x0,x0,z0,z1,-Math.PI/2]]){const L=Math.max(b-a,d-c);const g=new THREE.PlaneGeometry(L,.15);const uv=g.attributes.uv;for(let k=0;k<uv.count;k++)uv.setXY(k,uv.getX(k)*L/2,uv.getY(k)*.075);g.rotateY(ry);g.translate((a+b)/2,.075,(c+d)/2);addGeo(MAT.curb,g,false);}
  streetProps(B);const sp=SPECIAL[i+','+j];
  if(sp&&sp.kind==='park'){B.park=true;park(B);continue;}
  if(sp){special(B,sp);continue;}
  const R={x0:x0+SW,x1:x1-SW,z0:z0+SW,z1:z1-SW};
  if(B.dist==='docks'&&(i+j)%3===0){warehouses(B,{x0:R.x0,x1:R.x1,z0:R.z0,z1:(R.z0+R.z1)/2-1});containers(R.x0+1,R.x1-1,(R.z0+R.z1)/2+1,R.z1-1);continue;}
  fillDistrict(B,R,B.dist);}
 beach();skyline();roadMarkings();flushBuckets();
 const sm=scene.children.filter(o=>o.isMesh&&(o.material===ATLAS.neon));for(const m of sm)m.renderOrder=2;}
function beach(){const x0=W+HALF;topQuad(MAT.sand,x0,W+60,.02,-HALF-200,W+HALF+200,4,null,false);const wg=new THREE.PlaneGeometry(8,S+400);wg.rotateX(-Math.PI/2);wg.translate(W+60,.03,W/2);addGeo(MAT.wetsand,wg,false);
 const ocean=new THREE.Mesh(new THREE.PlaneGeometry(3000,3000,60,60),MAT.water);ocean.rotation.x=-Math.PI/2;ocean.position.set(W+62+1500,-.35,W/2);ocean.receiveShadow=false;scene.add(ocean);REFL.hide.push(ocean);
 /* boardwalk + pier */
 topQuad(MAT.planks,x0+.5,x0+6,.25,-HALF,W+HALF,3,null,false);for(let z=-HALF;z<W+HALF;z+=2.5)plainBox(MAT.darkMetal,x0+6,x0+6.06,.25,1.2,z,z+.06,{shadow:false});plainBox(MAT.darkMetal,x0+6,x0+6.06,1.1,1.18,-HALF,W+HALF,{shadow:false});
 const pz=W*.42;topQuad(MAT.planks,W+40,W+150,1.6,pz-4,pz+4,3,null,true);for(let x=W+40;x<W+150;x+=6)for(const s of[-1,1])cyl(MAT.wood,x,-2,pz+s*3.6,.22,.22,3.6,8);
 for(const s of[-1,1])plainBox(MAT.wood,W+40,W+150,2.6,2.7,pz+s*3.9-.05,pz+s*3.9+.05,{shadow:false});
 /* lifeguard towers, umbrellas */
 for(const z of[W*.18,W*.68]){const x=W+44;for(const[a,b]of[[-1,-1],[1,-1],[1,1],[-1,1]])plainBox(MAT.wood,x+a*1.2-.08,x+a*1.2+.08,0,2.2,z+b*1.2-.08,z+b*1.2+.08);plainBox(MAT.planks,x-1.6,x+1.6,2.2,2.35,z-1.6,z+1.6,{uvm:2});
  facadeBox(MAT.fac.plaster,x-1.3,x+1.3,2.35,4.5,z-1.3,z+1.3,{style:4,fh:2.2,bay:2.6,tint:0xf2c94a,top:4.4});const g=new THREE.ConeGeometry(2.2,1,4);g.rotateY(Math.PI/4);g.translate(x,5,z);addGeo(new THREE.MeshStandardMaterial({color:lin(0xd8362a),roughness:.8}),g,true);
  const r=new THREE.BoxGeometry(.9,.08,4.2);r.rotateX(.55);r.translate(x-.4,1.1,z+3);addGeo(MAT.planks,r,true);STATIC.push({x0:x-1.7,x1:x+1.7,z0:z-1.7,z1:z+1.7,h:5});}
 const UMB=[0xe8463a,0x2a8ad8,0xf2c200,0xffffff,0x2ab070];for(let k=0;k<26;k++){const z=srange(0,W),x=srange(W+20,W+52);cyl(MAT.whiteMetal,x,0,z,.04,.04,2.4,5);const cg=new THREE.ConeGeometry(1.5,.5,10,1,true);cg.translate(x,2.45,z);addGeo(new THREE.MeshStandardMaterial({color:lin(spick(UMB)),roughness:.8,side:THREE.DoubleSide}),cg,true);
  const tw=new THREE.PlaneGeometry(.9,1.9);tw.rotateX(-Math.PI/2);tw.translate(x+1.3,.04,z+.2);addGeo(new THREE.MeshStandardMaterial({color:lin(spick([0xff7a7a,0x7ab8ff,0xffe07a,0x9affc0])),roughness:1}),tw,false);}
 for(let z=-40;z<W+60;z+=12)PALMS.push([W+HALF+8+srange(-.5,.5),z+srange(-3,3),srange(.9,1.25)]);
 /* yacht on the horizon */
 const yx=W+380,yz=W*.55;plainBox(MAT.whiteMetal,yx-14,yx+14,0,3,yz-3,yz+3);plainBox(MAT.whiteMetal,yx-8,yx+6,3,5.2,yz-2.4,yz+2.4);plainBox(MAT.glassDark,yx-8.05,yx+6.05,3.8,4.6,yz-2.45,yz+2.45);plainBox(MAT.whiteMetal,yx-5,yx+2,5.2,6.8,yz-1.8,yz+1.8);}
function skyline(){for(let k=0;k<130;k++){const a=srange(Math.PI*.6,Math.PI*1.9),r=srange(S*.62+30,S*.62+260);const x=W/2+Math.cos(a)*r,z=W/2+Math.sin(a)*r;if(x>W+40)continue;const w=srange(16,38),d=srange(16,38),h=Math.round(srange(14,110)/4)*4;facadeBox(spick([MAT.fac.concrete,MAT.fac.tiles,MAT.fac.panels,MAT.fac.brick_red]),x-w/2,x+w/2,0,h,z-d/2,z+d/2,{style:spick([0,1,2]),fh:3.6,bay:3,top:h});topQuad(MAT.roof,x-w/2,x+w/2,h,z-d/2,z+d/2,4,null,false);}
 for(const[x,z,sx,sz]of[[W/2,-HALF-.4,S+2,.8],[W/2,W+HALF+.4,S+2,.8],[-HALF-.4,W/2,.8,S+2]])plainBox(MAT.trim,x-sx/2,x+sx/2,0,1.1,z-sz/2,z+sz/2,{uvm:2});
 for(let k=0;k<16;k++){const a=srange(Math.PI*.6,Math.PI*1.9),r=srange(900,1200);const g=new THREE.ConeGeometry(srange(160,300),srange(70,170),9);g.translate(W/2+Math.cos(a)*r,40,W/2+Math.sin(a)*r);addGeo(new THREE.MeshStandardMaterial({color:lin(0x5a5048),roughness:1}),g,false);}}
function roadMarkings(){const pos=[],col=[],idx=[];const Y=.012;const quad=(x0,z0,x1,z1,c)=>{const b=pos.length/3;pos.push(x0,Y,z0,x1,Y,z0,x0,Y,z1,x1,Y,z1);for(let i=0;i<4;i++)col.push(c[0],c[1],c[2]);idx.push(b,b+2,b+1,b+1,b+2,b+3);};
 const YEL=[.75,.52,.06],WHT=[.82,.82,.8];
 for(let k=0;k<=N;k++){const c=k*CELL;for(let s=0;s<N;s++){const a=s*CELL+HALF+3.6,b=(s+1)*CELL-HALF-3.6;
   quad(c-.22,a,c-.1,b,YEL);quad(c+.1,a,c+.22,b,YEL);quad(a,c-.22,b,c-.1,YEL);quad(a,c+.1,b,c+.22,YEL);
   quad(c-HALF+.35,a,c-HALF+.5,b,WHT);quad(c+HALF-.5,a,c+HALF-.35,b,WHT);quad(a,c-HALF+.35,b,c-HALF+.5,WHT);quad(a,c+HALF-.5,b,c+HALF-.35,WHT);}}
 for(let i=0;i<=N;i++)for(let j=0;j<=N;j++){const x=i*CELL,z=j*CELL;for(let s=-6.6;s<=6.6;s+=1.1){quad(x+s-.25,z-HALF-3,x+s+.25,z-HALF-.6,WHT);quad(x+s-.25,z+HALF+.6,x+s+.25,z+HALF+3,WHT);quad(x-HALF-3,z+s-.25,x-HALF-.6,z+s+.25,WHT);quad(x+HALF+.6,z+s-.25,x+HALF+3,z+s+.25,WHT);}
  quad(x-HALF+.3,z-HALF-3.6,x-.1,z-HALF-3.2,WHT);quad(x+.1,z+HALF+3.2,x+HALF-.3,z+HALF+3.6,WHT);quad(x-HALF-3.6,z+.1,x-HALF-3.2,z+HALF-.3,WHT);quad(x+HALF+3.2,z-HALF+.3,x+HALF+3.6,z-.1,WHT);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('color',new THREE.Float32BufferAttribute(col,3));const n=new Float32Array(pos.length);for(let i=1;i<n.length;i+=3)n[i]=1;g.setAttribute('normal',new THREE.BufferAttribute(n,3));g.setIndex(idx);
 const m=new THREE.Mesh(g,makeWet(new THREE.MeshStandardMaterial({vertexColors:true,roughness:.55,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}),{wet:.8}));m.receiveShadow=true;scene.add(m);}
/* ---- trees, palms, lamps, traffic lights (instanced) ---- */
function leafTex(palm){const[c,g]=cvs(256,256);g.clearRect(0,0,256,256);
 if(palm){g.translate(128,250);for(let i=0;i<60;i++){const t=i/60,y=-t*240,len=(1-Math.abs(t-.45)*1.6)*95+12;for(const s of[-1,1]){g.save();g.translate(0,y);g.rotate(s*(1.05-t*.4));g.fillStyle=`hsl(${rnd(85,105)},${rnd(35,50)}%,${rnd(22,34)}%)`;g.beginPath();g.ellipse(0,-len/2,4.5,len/2,0,0,7);g.fill();g.restore();}}g.fillStyle='#5a4a2a';g.fillRect(-2,-240,4,240);}
 else{for(let i=0;i<420;i++){const x=rnd(10,246),y=rnd(10,246);if(Math.hypot(x-128,y-128)>118)continue;g.save();g.translate(x,y);g.rotate(rnd(0,6.3));g.fillStyle=`hsl(${rnd(70,110)},${rnd(30,55)}%,${rnd(18,38)}%)`;g.beginPath();g.ellipse(0,0,rnd(5,9),rnd(9,15),0,0,7);g.fill();g.restore();}}
 const t=ctex(c);t.premultiplyAlpha=false;return t;}
const DYN={};
function plantTrees(){const o=new THREE.Object3D(),col=new THREE.Color();
 const inst=(geo,mat,arr,fn,shadow=true)=>{if(!arr.length)return null;const m=new THREE.InstancedMesh(geo,mat,arr.length);arr.forEach((p,k)=>{o.position.set(0,0,0);o.rotation.set(0,0,0);o.scale.set(1,1,1);fn(p,k);o.updateMatrix();m.setMatrixAt(k,o.matrix);});m.castShadow=shadow;m.receiveShadow=true;scene.add(m);return m;};
 const bark=new THREE.MeshStandardMaterial({color:lin(0x4a3a2c),roughness:.95});
 const trunk=new THREE.CylinderGeometry(.13,.24,3.6,7);trunk.translate(0,1.8,0);const br=[];for(let k=0;k<4;k++){const b=new THREE.CylinderGeometry(.04,.09,2,5);b.translate(0,1,0);b.rotateZ(.7);b.rotateY(k*1.57+.4);b.translate(0,2.8,0);br.push(b);}
 inst(mergeGeos([trunk,...br]),bark,TREES,p=>{o.position.set(p[0],.15,p[1]);o.scale.setScalar(p[2]);o.rotation.y=Math.random()*6;});
 const cards=[];for(let k=0;k<11;k++){const g=new THREE.PlaneGeometry(2.6,2.6);g.rotateX(rnd(-1.2,1.2));g.rotateY(rnd(0,3.14));g.translate(rnd(-1,1),rnd(3.4,5.6),rnd(-1,1));cards.push(g);}
 const lm=new THREE.MeshStandardMaterial({map:leafTex(false),alphaTest:.45,side:THREE.DoubleSide,roughness:.85});
 const leaves=inst(mergeGeos(cards),lm,TREES,p=>{o.position.set(p[0],.15,p[1]);o.scale.set(p[2],p[2]*rnd(.85,1.15),p[2]);o.rotation.y=Math.random()*6;});
 if(leaves)TREES.forEach((p,k)=>{col.setHSL(rnd(.0,.06),rnd(0,.2),rnd(.85,1));leaves.setColorAt(k,col);});
 const pt=new THREE.CylinderGeometry(.14,.24,9,8,10);{const pa=pt.attributes.position;for(let i=0;i<pa.count;i++){const y=pa.getY(i)+4.5;pa.setX(i,pa.getX(i)+Math.pow(y/9,2)*1.1);const ring=Math.abs(Math.sin(y*6))*.02;pa.setX(i,pa.getX(i)*(1+ring));pa.setZ(i,pa.getZ(i)*(1+ring));}pt.translate(0,4.5,0);pt.computeVertexNormals();}
 inst(pt,new THREE.MeshStandardMaterial({color:lin(0x8a7458),roughness:.95}),PALMS,p=>{o.position.set(p[0],p[0]>W?0:.15,p[1]);o.rotation.y=rnd(0,6);o.scale.setScalar(p[2]);});
 const fr=[];for(let k=0;k<11;k++){const g=new THREE.PlaneGeometry(1.5,3.6,1,6);const pa=g.attributes.position;for(let i=0;i<pa.count;i++){const y=pa.getY(i)+1.8;pa.setZ(i,-Math.pow(y/3.6,2)*1.6);pa.setX(i,pa.getX(i)*(1-Math.abs(y/3.6-.5)*.6));}g.translate(0,1.8,0);g.rotateX(-Math.PI/2+.5+rnd(-.15,.2));g.rotateY(k/11*Math.PI*2+rnd(-.2,.2));g.translate(1.1,9,0);fr.push(g);}
 const pm=new THREE.MeshStandardMaterial({map:leafTex(true),alphaTest:.4,side:THREE.DoubleSide,roughness:.8});
 inst(mergeGeos(fr),pm,PALMS,p=>{o.position.set(p[0],p[0]>W?0:.15,p[1]);o.rotation.y=rnd(0,6);o.scale.setScalar(p[2]);});}
/* traffic lights */
const TL={mats:{},pts:{}};let tlPhase={ns:'G',ew:'R'};
function buildTrafficLights(){const o=new THREE.Object3D();const poles=[],heads=[],lamps={nsR:[],nsY:[],nsG:[],ewR:[],ewY:[],ewG:[]};
 for(let i=0;i<=N;i++)for(let j=0;j<=N;j++){const x=i*CELL,z=j*CELL;for(const[sx,sz]of[[-1,-1],[1,1]]){const px=x+sx*(HALF+.7),pz=z+sz*(HALF+.7);if(px<0||pz<0||px>W||pz>W)continue;poles.push([px,pz,sx,sz]);
  for(const ax of['ns','ew']){const ry=ax==='ns'?(sz<0?0:Math.PI):(sx<0?Math.PI/2:-Math.PI/2);const armL=3.2;const hx=px+(ax==='ns'?-sx*armL:0)*0+(ax==='ew'?0:0),hz=pz;
   const ox=ax==='ns'?-sx*0:0;const hx2=ax==='ns'?px-sx*1.6:px,hz2=ax==='ew'?pz-sz*1.6:pz;heads.push([hx2,hz2,ry]);const fx=Math.sin(ry)*.17,fz=Math.cos(ry)*.17;
   lamps[ax+'R'].push([hx2+fx,5.15,hz2+fz,ry]);lamps[ax+'Y'].push([hx2+fx,4.82,hz2+fz,ry]);lamps[ax+'G'].push([hx2+fx,4.49,hz2+fz,ry]);}}}
 const pg=mergeGeos([(()=>{const g=new THREE.CylinderGeometry(.1,.13,5.8,8);g.translate(0,2.9,0);return g;})()]);const pm=new THREE.InstancedMesh(pg,MAT.darkMetal,poles.length);poles.forEach((p,k)=>{o.position.set(p[0],.15,p[1]);o.rotation.set(0,0,0);o.updateMatrix();pm.setMatrixAt(k,o.matrix);});pm.castShadow=true;scene.add(pm);
 const arm=new THREE.BoxGeometry(.08,.08,1.7);arm.translate(0,5.6,.85);const am=new THREE.InstancedMesh(arm,MAT.darkMetal,poles.length*2);let ai=0;poles.forEach(p=>{for(const ry of[Math.atan2(-p[2],0),Math.atan2(0,-p[3])]){o.position.set(p[0],.15,p[1]);o.rotation.set(0,ry,0);o.updateMatrix();am.setMatrixAt(ai++,o.matrix);}});scene.add(am);
 const hg=new THREE.BoxGeometry(.36,1.12,.28);hg.translate(0,4.82,0);const hm=new THREE.InstancedMesh(hg,new THREE.MeshStandardMaterial({color:lin(0x1a1b1d),roughness:.5}),heads.length);heads.forEach((p,k)=>{o.position.set(p[0],0,p[1]);o.rotation.set(0,p[2],0);o.updateMatrix();hm.setMatrixAt(k,o.matrix);});hm.castShadow=true;scene.add(hm);
 const lg=new THREE.CircleGeometry(.12,10);const cols={R:[3,.12,.05],Y:[3,1.4,.1],G:[.15,3,.6]};
 for(const key in lamps){const c=cols[key[2]];const m=new THREE.MeshBasicMaterial({color:new THREE.Color(.06,.06,.06)});m.userData.on=new THREE.Color(c[0],c[1],c[2]);TL.mats[key]=m;const im=new THREE.InstancedMesh(lg,m,lamps[key].length);lamps[key].forEach((p,k)=>{o.position.set(p[0],p[1],p[2]);o.rotation.set(0,p[3],0);o.updateMatrix();im.setMatrixAt(k,o.matrix);});scene.add(im);}}
function updLights(t){const c=t%22;const ns=c<9?'G':c<11?'Y':'R',ew=c>=11&&c<20?'G':c>=20?'Y':'R';tlPhase={ns,ew};for(const ax of['ns','ew'])for(const L of'RYG'){const on=(ax==='ns'?ns:ew)===L;const m=TL.mats[ax+L];if(on)m.color.copy(m.userData.on);else m.color.setRGB(.05,.05,.05);}}
