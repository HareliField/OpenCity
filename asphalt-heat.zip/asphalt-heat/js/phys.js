/* ================= physics (cannon-es) ================= */
const PH={w:null,cars:[],hits:[],mat:{},dyn:[]};
const CV=CANNON.Vec3;
function physInit(){
 const w=PH.w=new CANNON.World();w.gravity.set(0,-9.82,0);w.broadphase=new CANNON.SAPBroadphase(w);w.allowSleep=true;w.solver.iterations=8;
 w.defaultContactMaterial.friction=.4;w.defaultContactMaterial.restitution=.1;
 const mg=PH.mat.ground=new CANNON.Material('g'),mc=PH.mat.car=new CANNON.Material('c'),mp=PH.mat.prop=new CANNON.Material('p');
 w.addContactMaterial(new CANNON.ContactMaterial(mg,mc,{friction:.32,restitution:.1}));
 w.addContactMaterial(new CANNON.ContactMaterial(mc,mc,{friction:.25,restitution:.12}));
 w.addContactMaterial(new CANNON.ContactMaterial(mg,mp,{friction:.6,restitution:.2}));
 w.addContactMaterial(new CANNON.ContactMaterial(mc,mp,{friction:.3,restitution:.15}));
 w.addContactMaterial(new CANNON.ContactMaterial(mp,mp,{friction:.5,restitution:.15}));
 const g=new CANNON.Body({mass:0,material:mg});g.addShape(new CANNON.Plane());g.quaternion.setFromEuler(-Math.PI/2,0,0);w.addBody(g);PH.ground=g;
 w.addEventListener('preStep',()=>{for(const c of PH.cars){if(c.body.sleepState!==2)c.veh.updateVehicle(w.dt);}});
}
function physBox(x0,x1,y0,y1,z0,z1,mat){const b=new CANNON.Body({mass:0,material:mat||PH.mat.ground});b.addShape(new CANNON.Box(new CV((x1-x0)/2,(y1-y0)/2,(z1-z0)/2)));b.position.set((x0+x1)/2,(y0+y1)/2,(z0+z1)/2);PH.w.addBody(b);return b;}
function physStep(dt){PH.w.step(1/60,dt,3);}
/* ---- vehicles ---- */
function physCarAdd(c){const s=c.spec;if(c.body)return;
 const b=new CANNON.Body({mass:s.mass,material:PH.mat.car});const hl=s.L/2-.05,hw=s.W/2-.05,com=s.com;
 b.addShape(new CANNON.Box(new CV(hl,(s.b-.32)/2,hw)),new CV(0,(s.b+.32)/2-com,0));
 const cl=(s.L-s.hood-s.tr)/2*.8;b.addShape(new CANNON.Box(new CV(cl,(s.r-s.b)/2,hw-.14)),new CV((s.hood-s.tr)/2,(s.r+s.b)/2-com,0));
 b.angularDamping=.3;b.linearDamping=.02;b.allowSleep=true;b.sleepSpeedLimit=.15;b.sleepTimeLimit=1.5;b.car=c;
 const v=new CANNON.RaycastVehicle({chassisBody:b,indexRightAxis:2,indexForwardAxis:0,indexUpAxis:1});
 const wb=s.L*.31,rest=s.rest,cy=s.wr+rest-9.82/(4*s.k)-com;
 for(const[fx,sz]of[[-1,1],[-1,-1],[1,1],[1,-1]])v.addWheel({radius:s.wr,directionLocal:new CV(0,-1,0),axleLocal:new CV(0,0,1),suspensionStiffness:s.k,suspensionRestLength:rest,frictionSlip:fx<0?s.gripF:s.gripR,dampingRelaxation:s.k*.13,dampingCompression:s.k*.09,maxSuspensionForce:s.mass*40,rollInfluence:s.roll,maxSuspensionTravel:.3,customSlidingRotationalSpeed:-40,useCustomSlidingRotationalSpeed:true,chassisConnectionPointLocal:new CV(fx*wb,cy,sz*(s.W/2-.14))});
 for(const wi of v.wheelInfos){wi.suspensionLength=rest-9.82/(4*s.k);}
 v.world=PH.w;c.body=b;c.veh=v;c.steerA=0;
 b.addEventListener('collide',e=>{const ct=e.contact,iv=Math.abs(ct.getImpactVelocityAlongNormal());if(iv<2)return;const now=performance.now(),lh=c.lastHit||(c.lastHit={});if(now-(lh[e.body.id]||0)<350)return;lh[e.body.id]=now;const self=ct.bi===b,r=self?ct.ri:ct.rj;PH.hits.push({car:c,other:e.body,iv,px:b.position.x+r.x,py:b.position.y+r.y,pz:b.position.z+r.z,nx:ct.ni.x*(self?1:-1),nz:ct.ni.z*(self?1:-1)});});
 return b;}
function physCarOn(c){if(c.phys)return;physCarAdd(c);const b=c.body;b.position.set(c.pos.x,c.spec.com+.02,c.pos.z);b.quaternion.setFromEuler(0,c.h+Math.PI/2,0);b.velocity.set(Math.sin(c.h)*c.speed,0,Math.cos(c.h)*c.speed);b.angularVelocity.set(0,0,0);PH.w.addBody(b);PH.cars.push(c);c.phys=true;if(!c.driver&&Math.abs(c.speed)<.1)b.sleep();else b.wakeUp();}
function physCarOff(c){if(!c.phys)return;PH.w.removeBody(c.body);const i=PH.cars.indexOf(c);if(i>=0)PH.cars.splice(i,1);c.phys=false;}
const _f=new CV(),_u=new CV();
function physCarRead(c){const b=c.body;b.quaternion.vmult(new CV(-1,0,0),_f);b.quaternion.vmult(new CV(0,1,0),_u);
 const hl=Math.hypot(_f.x,_f.z)||1;c.h=Math.atan2(_f.x,_f.z);c.pos.set(b.position.x,0,b.position.z);c.vel.set(b.velocity.x,0,b.velocity.z);c.speed=(b.velocity.x*_f.x+b.velocity.z*_f.z)/hl;c.upY=_u.y;c.air=c.veh.numWheelsOnGround===0;}
function physCarSet(c,x,z,h,speed){c.pos.set(x,0,z);c.h=h;c.speed=speed||0;if(!c.phys)return;const b=c.body;b.position.set(x,c.spec.com+.02,z);b.quaternion.setFromEuler(0,h+Math.PI/2,0);b.velocity.set(Math.sin(h)*c.speed,0,Math.cos(h)*c.speed);b.angularVelocity.set(0,0,0);b.wakeUp();}
function physCarControl(c,thr,steer,hb,dt){const v=c.veh,s=c.spec,b=c.body;if(thr||steer)b.wakeUp();if(b.sleepState===2)return;
 const sp=c.speed,as=Math.abs(sp);
 const lim=Math.min(.62,Math.atan(s.L*.62*s.gripF*9/(sp*sp+.01))*1.25),tgt=steer*lim,rate=(Math.abs(tgt)<Math.abs(c.steerA)?5:3.2)*dt;
 c.steerA+=Math.max(-rate,Math.min(rate,tgt-c.steerA));v.setSteeringValue(c.steerA,0);v.setSteeringValue(c.steerA,1);
 let F=0,B=0;const vmax=s.max*(c.hp<c.max*.35?.65:1);
 if(thr>0){if(sp<-1.5)B=s.brake;else F=thr*s.F*Math.max(0,1-Math.pow(as/vmax,2.2))*(as<vmax?1:0);}
 else if(thr<0){if(sp>1.5)B=-thr*s.brake;else F=thr*s.F*.6*Math.max(0,1-as/9);}
 else B=s.brake*.04;
 const fe=-F;if(s.awd){for(let i=0;i<4;i++)v.applyEngineForce(fe/4,i);}else{v.applyEngineForce(0,0);v.applyEngineForce(0,1);v.applyEngineForce(fe/2,2);v.applyEngineForce(fe/2,3);}
 v.setBrake(B,0);v.setBrake(B,1);v.setBrake(hb?s.brake*1.5:B*.7,2);v.setBrake(hb?s.brake*1.5:B*.7,3);
 const gr=hb?s.gripR*.45:s.gripR;v.wheelInfos[2].frictionSlip=gr;v.wheelInfos[3].frictionSlip=gr;
 c.braking=B>s.brake*.2||hb;}
/* ---- loose dynamic bodies (props, ragdolls) ---- */
function physDyn(shape,mass,x,y,z,offset){const b=new CANNON.Body({mass,material:PH.mat.prop});b.addShape(shape,offset);b.position.set(x,y,z);b.allowSleep=true;b.sleepSpeedLimit=.2;b.sleepTimeLimit=1;b.angularDamping=.25;b.linearDamping=.05;PH.w.addBody(b);return b;}
function physRemove(b){if(b&&b.world)PH.w.removeBody(b);}
function physImpulseRadial(x,y,z,r,force,skip){for(const b of PH.w.bodies){if(b.type!==1||b===skip)continue;const dx=b.position.x-x,dy=b.position.y-y+.6,dz=b.position.z-z,d=Math.hypot(dx,dy,dz);if(d>r)continue;const dd=Math.max(d,.5),f=(1-d/r),dv=Math.min(force/1400*f,14)*(b.mass<200?1.6:1);b.wakeUp();b.applyImpulse(new CV(dx/dd*dv*b.mass,(dy/dd+.6)*dv*b.mass*.6,dz/dd*dv*b.mass),new CV(.3*(Math.random()-.5),.1,.3*(Math.random()-.5)));}}

