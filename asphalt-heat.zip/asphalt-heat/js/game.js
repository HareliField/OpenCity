/* ================= game systems ================= */
const MINX=-HALF+.6,MAXX=W+56,MINZ=-HALF+.6,MAXZ=W+HALF-.6;
/* ---- world queries ---- */
function blockOf(x,z){const i=Math.floor(x/CELL),j=Math.floor(z/CELL);if(i<0||j<0||i>=N||j>=N)return null;const B=blocks[i*N+j];return(x>B.x0&&x<B.x1&&z>B.z0&&z<B.z1)?B:null;}
const groundY=(x,z)=>blockOf(x,z)?.15:0;
function pushOut(p,r,R){const cx=clamp(p.x,R.x0,R.x1),cz=clamp(p.z,R.z0,R.z1);let dx=p.x-cx,dz=p.z-cz;const d2=dx*dx+dz*dz;if(d2>=r*r)return null;
 if(d2<1e-8){const l=p.x-R.x0,rr=R.x1-p.x,t=p.z-R.z0,b=R.z1-p.z,m=Math.min(l,rr,t,b);if(m===l){p.x=R.x0-r;return[-1,0];}if(m===rr){p.x=R.x1+r;return[1,0];}if(m===t){p.z=R.z0-r;return[0,-1];}p.z=R.z1+r;return[0,1];}
 const d=Math.sqrt(d2);dx/=d;dz/=d;p.x=cx+dx*r;p.z=cz+dz*r;return[dx,dz];}
const STATICGRID={};
function indexStatic(){for(const R of STATIC){const i=clamp(Math.floor((R.x0+R.x1)/2/CELL),0,N-1),j=clamp(Math.floor((R.z0+R.z1)/2/CELL),0,N-1);blocks[i*N+j].bld.push(R);}}
function collideWorld(p,r){const i=Math.floor(p.x/CELL),j=Math.floor(p.z/CELL);let hit=null;
 for(let a=i-1;a<=i+1;a++)for(let b=j-1;b<=j+1;b++){if(a<0||b<0||a>=N||b>=N)continue;for(const R of blocks[a*N+b].bld){const n=pushOut(p,r,R);if(n)hit=n;}}
 if(p.x<MINX+r){p.x=MINX+r;hit=[1,0];}if(p.x>MAXX-r){p.x=MAXX-r;hit=[-1,0];}if(p.z<MINZ+r){p.z=MINZ+r;hit=[0,1];}if(p.z>MAXZ-r){p.z=MAXZ-r;hit=[0,-1];}return hit;}
function segRect(ax,az,dx,dz,R){let t0=0,t1=1;
 if(Math.abs(dx)<1e-9){if(ax<R.x0||ax>R.x1)return-1;}else{let u=(R.x0-ax)/dx,v=(R.x1-ax)/dx;if(u>v){const s=u;u=v;v=s;}t0=Math.max(t0,u);t1=Math.min(t1,v);if(t0>t1)return-1;}
 if(Math.abs(dz)<1e-9){if(az<R.z0||az>R.z1)return-1;}else{let u=(R.z0-az)/dz,v=(R.z1-az)/dz;if(u>v){const s=u;u=v;v=s;}t0=Math.max(t0,u);t1=Math.min(t1,v);if(t0>t1)return-1;}return t0;}
function rayWorld(ax,az,bx,bz){let best=1;const dx=bx-ax,dz=bz-az;const i0=Math.max(0,Math.floor(Math.min(ax,bx)/CELL)),i1=Math.min(N-1,Math.floor(Math.max(ax,bx)/CELL)),j0=Math.max(0,Math.floor(Math.min(az,bz)/CELL)),j1=Math.min(N-1,Math.floor(Math.max(az,bz)/CELL));
 for(let a=i0;a<=i1;a++)for(let b=j0;b<=j1;b++)for(const R of blocks[a*N+b].bld){const t=segRect(ax,az,dx,dz,R);if(t>=0&&t<best)best=t;}return best;}
const los=(a,b)=>rayWorld(a.x,a.z,b.x,b.z)>=1;
const nearestNode=p=>[clamp(Math.round(p.x/CELL),0,N),clamp(Math.round(p.z/CELL),0,N)];
function neighbors(n){const r=[];for(const[a,b]of[[1,0],[-1,0],[0,1],[0,-1]]){const i=n[0]+a,j=n[1]+b;if(i>=0&&j>=0&&i<=N&&j<=N)r.push([i,j]);}return r;}
const dist2=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
function physWorld(){for(const B of blocks){physBox(B.x0,B.x1,0,.15,B.z0,B.z1);for(const R of B.bld)physBox(R.x0,R.x1,0,Math.min(R.h||12,30),R.z0,R.z1);}
 physBox(-HALF-1,W+60,0,2,-HALF-1.2,-HALF-.2);physBox(-HALF-1,W+60,0,2,W+HALF+.2,W+HALF+1.2);physBox(-HALF-1.2,-HALF-.2,0,2,-HALF,W+HALF);physBox(W+64,W+66,-2,3,-HALF,W+HALF);}
/* ---- particles / tracers ---- */
const parts=[];let pi=0;
function initParts(){for(let i=0;i<220;i++){const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex(),transparent:true,depthWrite:false}));sp.visible=false;scene.add(sp);parts.push({sp,life:0,age:0,v:new V3(),s0:1,s1:1,g:0,add:false});}}
function emit(x,y,z,vx,vy,vz,life,s0,s1,color,add,grav=0){const p=parts[pi=(pi+1)%parts.length];p.sp.visible=true;p.sp.position.set(x,y,z);p.v.set(vx,vy,vz);p.life=life;p.age=0;p.s0=s0;p.s1=s1;p.g=grav;p.add=add;p.sp.material.color.setHex(color);if(add)p.sp.material.color.multiplyScalar(2.5);p.sp.material.blending=add?THREE.AdditiveBlending:THREE.NormalBlending;}
function updParts(dt){for(const p of parts){if(!p.sp.visible)continue;p.age+=dt;if(p.age>=p.life){p.sp.visible=false;continue;}const k=p.age/p.life;p.v.y-=p.g*dt;p.sp.position.addScaledVector(p.v,dt);if(p.sp.position.y<.05&&p.g>0){p.sp.position.y=.05;p.v.multiplyScalar(.3);}p.sp.scale.setScalar(p.s0+(p.s1-p.s0)*k);p.sp.material.opacity=(1-k)*(p.add?1:.55);}}
const tracers=[];let ti=0;
function initTracers(){for(let i=0;i<24;i++){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));const l=new THREE.Line(g,new THREE.LineBasicMaterial({color:new THREE.Color(3,2.4,1.2),transparent:true}));l.visible=false;l.frustumCulled=false;scene.add(l);tracers.push({l,t:0});}}
function tracer(a,b){const T=tracers[ti=(ti+1)%tracers.length];const p=T.l.geometry.attributes.position;p.setXYZ(0,a.x,a.y,a.z);p.setXYZ(1,b.x,b.y,b.z);p.needsUpdate=true;T.l.visible=true;T.t=.05;}
/* skid marks */
const SKID={mesh:null,n:0,max:600};
function initSkids(){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(SKID.max*12),3));const idx=[];for(let i=0;i<SKID.max;i++){const b=i*4;idx.push(b,b+2,b+1,b+1,b+2,b+3);}g.setIndex(idx);
 SKID.mesh=new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:0x050505,transparent:true,opacity:.55,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4}));SKID.mesh.frustumCulled=false;scene.add(SKID.mesh);}
function skid(c,i,pos){const L=c.skidLast||(c.skidLast=[null,null,null,null]);const last=L[i];const y=groundY(pos.x,pos.z)+.02;if(last&&Math.hypot(pos.x-last.x,pos.z-last.z)<3){const dx=pos.x-last.x,dz=pos.z-last.z,l=Math.hypot(dx,dz)||1,nx=-dz/l*.11,nz=dx/l*.11;const P=SKID.mesh.geometry.attributes.position,k=(SKID.n++%SKID.max)*4;
 P.setXYZ(k,last.x+nx,y,last.z+nz);P.setXYZ(k+1,last.x-nx,y,last.z-nz);P.setXYZ(k+2,pos.x+nx,y,pos.z+nz);P.setXYZ(k+3,pos.x-nx,y,pos.z-nz);P.needsUpdate=true;}L[i]={x:pos.x,z:pos.z};}
/* ---- audio ---- */
let ac=null,master,nbuf,engO,engO2,engG,engF,sirO,sirG,heliG,scrG,scrF;
function initAudio(){try{ac=new(window.AudioContext||window.webkitAudioContext)();master=ac.createGain();master.gain.value=.55;master.connect(ac.destination);
 nbuf=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);const d=nbuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 engO=ac.createOscillator();engO.type='sawtooth';engO2=ac.createOscillator();engO2.type='square';engF=ac.createBiquadFilter();engF.type='lowpass';engF.frequency.value=420;engG=ac.createGain();engG.gain.value=0;const g2=ac.createGain();g2.gain.value=.35;engO.connect(engF);engO2.connect(g2).connect(engF);engF.connect(engG).connect(master);engO.start();engO2.start();
 sirO=ac.createOscillator();sirO.type='triangle';sirG=ac.createGain();sirG.gain.value=0;sirO.connect(sirG).connect(master);sirO.start();
 const hs=ac.createBufferSource();hs.buffer=nbuf;hs.loop=true;const bp=ac.createBiquadFilter();bp.type='lowpass';bp.frequency.value=180;const amp=ac.createGain();amp.gain.value=.5;const lfo=ac.createOscillator();lfo.frequency.value=13;const ld=ac.createGain();ld.gain.value=.5;lfo.connect(ld).connect(amp.gain);heliG=ac.createGain();heliG.gain.value=0;hs.connect(bp).connect(amp).connect(heliG).connect(master);hs.start();lfo.start();
 const ss=ac.createBufferSource();ss.buffer=nbuf;ss.loop=true;scrF=ac.createBiquadFilter();scrF.type='bandpass';scrF.frequency.value=1800;scrF.Q.value=6;scrG=ac.createGain();scrG.gain.value=0;ss.connect(scrF).connect(scrG).connect(master);ss.start();}catch(e){ac=null;}}
function noise(dur,freq,vol){if(!ac||vol<.01)return;const s=ac.createBufferSource();s.buffer=nbuf;const f=ac.createBiquadFilter();f.type='lowpass';f.frequency.value=freq;const g=ac.createGain();const t=ac.currentTime;g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);s.connect(f).connect(g).connect(master);s.start(t,Math.random()*.5);s.stop(t+dur);}
function beep(f,dur,vol,type='square'){if(!ac)return;const o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.value=f;const t=ac.currentTime;g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g).connect(master);o.start(t);o.stop(t+dur);}
let player;const distVol=(x,z,v)=>v*clamp(1-Math.hypot(x-player.pos.x,z-player.pos.z)/110,0,1);
/* ---- roster ---- */
let CAST={},ROLE={};
function pickChar(role){const l=ROLE[role]||ROLE.m;return pick(l);}
function pedRoleFor(B){const d=B?B.dist:'midtown';const r=Math.random();if(d==='beach'&&r<.45&&ROLE.beach)return'beach';if(d==='downtown'&&r<.35)return pick(['m','f'])==='m'?'mb':'fb';if(d==='docks'&&r<.3&&ROLE.work)return'work';if(B&&B.i===5&&B.j<=2&&r<.25&&ROLE.medic)return'medic';return r<.52?'m':'f';}
/* ---- game state ---- */
const peds=[],cops=[],gang=[],guards=[],pickups=[],helis=[],cars=[];let clerk=null;
let heat=0,wanted=0,evadeT=0,state='loading',deadT=0,deadKind='',shake=0,camYaw=0,lookYaw=0,lookPitch=0,time=0,robbing=null,lastShot=-99,shopOpen=false,roadblockT=20,heliT=0,hurtT=0;
const TH=[0,10,40,100,200,350];
const LV={cars:[0,1,2,4,5,7],acc:[0,0,.2,.3,.4,.5],dmg:[0,5,6,8,10,13],evade:[0,7,15,25,40,60],sees:[0,30,40,50,60,70],
 desc:['','POLICE ALERTED|Cops will try to arrest you','ARMED RESPONSE|Cops shoot if you are armed','SHOOT ON SIGHT|Roadblocks · cops fire from cars','SWAT + HELICOPTER|Armored vans · searchlight tracking','MILITARY|Army units · two helicopters']};
const WEAP={fist:{n:'FISTS',rate:.42},pistol:{n:'PISTOL',rate:.27,dmg:34,acc:.85,range:45},smg:{n:'SMG',rate:.085,dmg:17,acc:.7,range:40},shotgun:{n:'SHOTGUN',rate:.9,dmg:30,acc:.9,range:18,pel:6}};
/* ---- HUD helpers ---- */
const toastEl=$('toast');let toastT=0,bannerT=0;
function toast(msg,ms=2000){toastEl.textContent=msg;toastEl.classList.add('on');toastT=ms/1000;}
function banner(L){const[a,b]=LV.desc[L].split('|');const el=$('banner');el.innerHTML='';const bb=document.createElement('b');bb.textContent='★'.repeat(L)+' '+a;el.append(bb,document.createTextNode(b));el.classList.add('on');bannerT=3;}
function hurtFlash(){hurtT=.35;}
function levelOf(h){let L=0;for(let k=1;k<=5;k++)if(h>=TH[k])L=k;return L;}
function witnessed(x,z){if(wanted>0)return true;for(const p of peds)if(!p.dead&&Math.hypot(p.pos.x-x,p.pos.z-z)<35)return true;for(const c of cops)if(!c.dead&&Math.hypot(c.pos.x-x,c.pos.z-z)<45)return true;for(const c of cars)if(c.driver==='police'&&Math.hypot(c.pos.x-x,c.pos.z-z)<60)return true;return false;}
function crime(amt,x,z,noW){if(!noW&&!witnessed(x,z))return;heat=Math.min(500,heat+amt);evadeT=0;}
function damagePlayer(d){if(state!=='play')return;if(player.armor>0){const a=Math.min(player.armor,d*.7);player.armor-=a;d-=a;}player.hp-=d;hurtFlash();}
/* ================= cars ================= */
function liveryOf(t){return t==='police'?'police':t==='taxi'?'taxi':t==='swat'?'swat':t==='amb'?'amb':'none';}
function spawnCar(type,x,z,h,driver){const s=CARSPEC[type],lv=liveryOf(type);const color=type==='taxi'?0xf2c200:lv!=='none'?0xffffff:pick(carColors);
 const M=makeCarMesh(type,color,lv);scene.add(M.grp);const mats=[M.mats[0],glassMat,darkMat,LENS.headOff,LENS.tailOff,carPlateMat()];M.body.material=mats;
 const c={type,spec:s,mesh:M.grp,body3:M.body,beam:M.beam,bar:M.bar,mats,pos:new V3(x,0,z),vel:new V3(),h,speed:0,hp:s.hp,max:s.hp,driver,ai:null,route:null,burn:0,dead:false,wreckT:0,stuck:0,rev:0,wait:0,cd:rnd(1,2),siren:false,block:false,unit:null,phys:false,body:null,veh:null,upY:1,spin:0,steerA:0,lightsOn:!!driver};
 M.grp.position.copy(c.pos);M.grp.rotation.y=h;cars.push(c);return c;}
function paintCar(c,color){const m=carPaint(c.type,color,liveryOf(c.type));c.mats[0]=m;c.body3.material=c.mats.slice();}
function removeCar(c){physCarOff(c);scene.remove(c.mesh);if(c.ownGeo)c.body3.geometry.dispose();const i=cars.indexOf(c);if(i>=0)cars.splice(i,1);}
function setCarLights(c,brake){const on=!!(c.driver||c===player.car)&&!c.dead;const head=on?LENS.headOn:LENS.headOff,tail=on?(brake?LENS.tailBrake:LENS.tailOn):(brake?LENS.tailBrake:LENS.tailOff);
 if(c.mats[3]!==head||c.mats[4]!==tail){c.mats[3]=head;c.mats[4]=tail;c.body3.material=c.mats.slice();}c.beam.visible=on;}
const _cqc=new THREE.Quaternion(),_cv3=new V3(),_cq90=new THREE.Quaternion().setFromAxisAngle(new V3(0,1,0),-Math.PI/2);
function syncCarMesh(c){if(c.phys){const b=c.body;_cqc.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w).multiply(_cq90);c.mesh.quaternion.copy(_cqc);_cv3.set(0,-c.spec.com,0).applyQuaternion(_cqc);c.mesh.position.set(b.position.x+_cv3.x,b.position.y+_cv3.y,b.position.z+_cv3.z);}
 else{c.mesh.position.set(c.pos.x,0,c.pos.z);c.mesh.rotation.set(0,c.h,0);}}
function pushWheels(c){if(!c.mesh.visible)return;const s=c.spec;
 if(c.phys){for(let i=0;i<4;i++){c.veh.updateWheelTransform(i);const t=c.veh.wheelInfos[i].worldTransform;wheelPushQ(t.position,t.quaternion,s.wr/.335);
   const wi=c.veh.wheelInfos[i];if(c===player.car&&wi.isInContact&&(wi.sliding||(i>1&&c.hb&&Math.abs(c.speed)>6))){skid(c,i,t.position);c.sliding=true;}else if(c.skidLast)c.skidLast[i]=null;}}
 else{c.spin+=c.speed*(1/60)/s.wr;for(const[sx,sz]of[[1,1],[-1,1],[1,-1],[-1,-1]]){_cv3.set(sx*(s.W/2-.14),s.wr,sz*s.wb).applyQuaternion(c.mesh.quaternion).add(c.mesh.position);wheelPush(_cv3.x,_cv3.y,_cv3.z,c.mesh.quaternion,0,c.spin,s.wr/.335);}}}
function damageCar(c,amt){if(c.dead)return;c.hp-=amt;if(c.hp<=0){c.hp=0;c.dead=true;c.burn=4;const lx=Math.cos(c.h)*2.3,lz=-Math.sin(c.h)*2.3;
 if(c.driver==='ai'){c.driver=null;ejectPed(c.pos.x+lx,c.pos.z+lz,c.pos.x,c.pos.z);}
 if(c.driver==='police'){c.driver=null;spawnUnit(c.unit||'cop',c.pos.x+lx,c.pos.z+lz);}
 setCarLights(c,false);if(c===player.car)toast("GET OUT! IT'S GONNA BLOW",1800);}}
const _inv=new THREE.Matrix4(),_lp=new V3();
function onCarHit(h){const c=h.car,o=h.other;if(!cars.includes(c))return;const oc=o&&o.car;let iv=h.iv;if(iv<3)return;
 const mr=oc?clamp(oc.spec.mass/c.spec.mass,.3,3):(o&&o.prop?clamp(o.mass/c.spec.mass*4,.05,1):1.4);const dmg=Math.max(0,iv-4.5)*1.05*mr;
 if(dmg>0)damageCar(c,dmg);
 if(iv>4.5&&c.mesh.visible){c.mesh.updateMatrixWorld();_inv.copy(c.mesh.matrixWorld).invert();_lp.set(h.px,h.py,h.pz).applyMatrix4(_inv);_lp.y=clamp(_lp.y,c.spec.gc+.2,c.spec.r-.1);carDent(c,_lp.x*1.05,_lp.y,_lp.z*1.02,Math.min(.22,(iv-4)*.018*mr));
  if(iv>7)for(let k=0;k<6;k++)emit(h.px,h.py+.3,h.pz,rnd(-3,3),rnd(1,4),rnd(-3,3),.4,.06,.05,0xffd29a,true,9);}
 if(iv>5){noise(.25+Math.min(iv,25)*.015,700+iv*30,distVol(h.px,h.pz,Math.min(1,iv/16)));if(c===player.car||oc===player.car){shake=Math.max(shake,Math.min(1,iv/20));if(c===player.car&&iv>16)damagePlayer((iv-16)*.9);}}
 if(oc&&(c===player.car||oc===player.car)){const other=c===player.car?oc:c;if(other.driver==='police'&&iv>7&&wanted<2)crime(12,other.pos.x,other.pos.z,true);if(other.driver==='ai'&&iv>6)other.angry=4;}}
function onPropHit(p,iv,c){if(c===player.car){if(p.t==='hydrant')toast('',1);if(Math.random()<.3)crime(2,p.x,p.z);}noise(.2,p.t==='lamp'||p.t==='hydrant'?500:1200,distVol(p.x,p.z,Math.min(.7,iv/14)));}
function explode(c){c.burn=0;c.wreckT=0;c.mats[0]=burntMat;c.mats[1]=burntMat;c.body3.material=c.mats.slice();if(c.bar){c.bar.r.material=SIREN.offR;c.bar.b.material=SIREN.offB;}c.beam.visible=false;
 if(c===player.car)player.hp=0;explodeAt(c.pos.x,c.pos.z,9,c);if(c.phys){c.body.wakeUp();c.body.applyImpulse(new CV(rnd(-1,1)*c.spec.mass*1.2,c.spec.mass*4.5,rnd(-1,1)*c.spec.mass*1.2),new CV(rnd(-1,1),.5,rnd(-1,1)));}}
function explodeAt(x,z,r,src){for(let k=0;k<34;k++)emit(x,1,z,rnd(-8,8),rnd(3,12),rnd(-8,8),rnd(.5,1.1),2,6,pick([0xffa030,0xff6020,0xffd060]),true,6);
 for(let k=0;k<18;k++)emit(x+rnd(-1,1),1.5,z+rnd(-1,1),rnd(-2,2),rnd(2,5),rnd(-2,2),rnd(1.8,3.2),3,11,0x2a2624,false);
 boomL.position.set(x,3,z);boomL.intensity=30;noise(1.6,480,distVol(x,z,1));const dP=Math.hypot(x-player.pos.x,z-player.pos.z);shake=Math.max(shake,clamp(1-dP/60,0,1));
 if(!player.car&&dP<r){damagePlayer(80*(1-dP/r));knockPlayer((player.pos.x-x)/(dP||1)*8,6,(player.pos.z-z)/(dP||1)*8);}
 for(const o of cars){if(o===src)continue;const d=Math.hypot(o.pos.x-x,o.pos.z-z);if(d<r){damageCar(o,70*(1-d/r)+10);if(!o.phys)physCarOn(o);}}
 physImpulseRadial(x,.5,z,r*1.5,12000,src&&src.body);
 for(const p of peds)if(!p.dead&&Math.hypot(p.pos.x-x,p.pos.z-z)<r)killPed(p,(p.pos.x-x)*2,6,(p.pos.z-z)*2,false);
 for(const arr of[cops,gang,guards])for(const u of arr)if(!u.dead&&Math.hypot(u.pos.x-x,u.pos.z-z)<r)hitUnit(u,999,u.pos.x-x,u.pos.z-z,false,true);
 scare(x,z,45);}
/* ---- driving ---- */
function kinematicDrive(c,thr,steer,dt){const s=c.spec;const tgt=thr*s.max;c.speed+=(clamp(tgt-c.speed,-12*dt,6*dt));c.h+=steer*clamp(c.speed/7,-1,1)*1.6*dt;c.pos.x+=Math.sin(c.h)*c.speed*dt;c.pos.z+=Math.cos(c.h)*c.speed*dt;c.vel.set(Math.sin(c.h)*c.speed,0,Math.cos(c.h)*c.speed);}
function drive(c,thr,steer,hb,dt){c.hb=hb;if(c.phys)physCarControl(c,thr,steer,hb,dt);else kinematicDrive(c,Math.max(0,thr),steer,dt);if(c.driver)setCarLights(c,c.braking||thr<0&&c.speed>1);}
function blockedAhead(c){const fx=Math.sin(c.h),fz=Math.cos(c.h);const chk=(x,z,w)=>{const dx=x-c.pos.x,dz=z-c.pos.z,f=dx*fx+dz*fz;if(f<1.5||f>10)return false;return Math.abs(dx*fz-dz*fx)<(w||2.3);};
 for(const o of cars)if(o!==c&&chk(o.pos.x,o.pos.z))return true;if(!player.car&&chk(player.pos.x,player.pos.z,1.8))return true;
 for(const p of peds)if(!p.dead&&(p.mode==='flee'||p.cross)&&chk(p.pos.x,p.pos.z,1.8))return true;return false;}
function aiTraffic(c,dt){if(!c.ai){const a=nearestNode(c.pos);c.ai={a,b:pick(neighbors(a))};}
 const A=c.ai.a,B=c.ai.b,dx=Math.sign(B[0]-A[0]),dz=Math.sign(B[1]-A[1]),rx=-dz,rz=dx;const tx=B[0]*CELL+rx*LANE,tz=B[1]*CELL+rz*LANE,along=(tx-c.pos.x)*dx+(tz-c.pos.z)*dz;
 if(along<5){const opts=neighbors(B).filter(n=>!(n[0]===A[0]&&n[1]===A[1]));let nb=opts.find(n=>n[0]-B[0]===dx&&n[1]-B[1]===dz);if(!nb||Math.random()<.4)nb=pick(opts);c.ai.a=B;c.ai.b=nb;}
 const look=c.phys?Math.max(7,Math.abs(c.speed)*.9):8;const k=along-Math.min(Math.max(along,0),look),gx=tx-dx*k,gz=tz-dz*k;const diff=wrapA(Math.atan2(gx-c.pos.x,gz-c.pos.z)-c.h);
 let target=Math.abs(diff)>.3?6.5:(c.type==='police'?13:11.5);
 const light=dz?tlPhase.ns:tlPhase.ew;if(light!=='G'&&along>11.5&&along<26&&!c.siren)target=Math.min(target,Math.max(0,(along-12.8)*.85));
 if(blockedAhead(c)){c.wait+=dt;if(c.wait<5)target=0;else if(c.wait>6.5)c.wait=0;}else c.wait=0;
 if(c.phys&&c.upY<.4){c.flipT=(c.flipT||0)+dt;if(c.flipT>3&&c.driver==='ai'){c.driver=null;ejectPed(c.pos.x+2,c.pos.z,c.pos.x,c.pos.z);}}
 const thr=clamp((target-c.speed)*.35,-1,1);drive(c,target<.5&&c.speed<1.5?-.15:thr,clamp(diff*2.2,-1,1),false,dt);}
function aiPolice(c,dt){const tgt=player.car?player.car.pos:player.pos;const d=dist2(c.pos,tgt);const L=wanted;const see=d<70&&los(c.pos,tgt);let gx,gz;
 if(d<45&&see){gx=tgt.x;gz=tgt.z;if(player.car&&L>=2){gx+=player.car.vel.x*.5;gz+=player.car.vel.z*.5;}}
 else{if(!c.route)c.route={b:nearestNode(c.pos)};const B=c.route.b;if(Math.hypot(B[0]*CELL-c.pos.x,B[1]*CELL-c.pos.z)<9){const tn=nearestNode(tgt);let best=B,bd=1e9;for(const n of neighbors(B)){const dd=Math.abs(n[0]-tn[0])+Math.abs(n[1]-tn[1])+Math.random()*.6;if(dd<bd){bd=dd;best=n;}}c.route.b=best;}
  gx=c.route.b[0]*CELL;gz=c.route.b[1]*CELL;if(tgt.x>W+HALF&&c.pos.x>W-20){gx=tgt.x;gz=tgt.z;}}
 const diff=wrapA(Math.atan2(gx-c.pos.x,gz-c.pos.z)-c.h);
 if(c.rev>0){c.rev-=dt;drive(c,-1,diff>0?-1:1,false,dt);return;}
 if(Math.abs(c.speed)<1.5)c.stuck+=dt;else c.stuck=0;if(c.stuck>1.6){c.stuck=0;c.rev=1.2;}
 if(c.phys&&c.upY<.4){c.driver=null;spawnUnit(c.unit||'cop',c.pos.x+2,c.pos.z);return;}
 const deploy=!player.car?(d<16&&see):(L<=2&&d<10&&Math.abs(player.car.speed)<3);
 if(deploy&&state==='play'){drive(c,-1,0,true,dt);if(Math.abs(c.speed)<2.2){c.driver=null;c.ai=null;c.siren=true;setCarLights(c,false);c.beam.visible=false;const lx=Math.cos(c.h)*2.4,lz=-Math.sin(c.h)*2.4;const k=c.unit||'cop';spawnUnit(k,c.pos.x+lx,c.pos.z+lz);if(L>=3||k!=='cop')spawnUnit(k,c.pos.x-lx,c.pos.z-lz);if(k!=='cop'&&L>=4)spawnUnit(k,c.pos.x-Math.sin(c.h)*3.5,c.pos.z-Math.cos(c.h)*3.5);}return;}
 const top=c.spec.max*[0,.6,.74,.88,1,1.08][L];const want=Math.abs(diff)>1.2&&d>14?9:(d<12&&!player.car?4:top);const thr=clamp((want-c.speed)*.4,-1,1);
 drive(c,thr,clamp(diff*2.4,-1,1),Math.abs(diff)>1.3&&c.speed>14,dt);
 if(L>=3&&see&&d<28&&state==='play'){c.cd-=dt;if(c.cd<=0){c.cd=rnd(.8,1.4)/(L-2);unitShootFrom(c.pos.x,1.3,c.pos.z,LV.acc[L]*.8,LV.dmg[L]);}}}
/* ================= people ================= */
function perim(B){return{x0:B.x0+1.7,x1:B.x1-1.7,z0:B.z0+1.7,z1:B.z1-1.7};}
function perimPos(R,t){const w=R.x1-R.x0,h=R.z1-R.z0,L=2*(w+h);t=((t%L)+L)%L;if(t<w)return[R.x0+t,R.z0];t-=w;if(t<h)return[R.x1,R.z0+t];t-=h;if(t<w)return[R.x1-t,R.z1];t-=w;return[R.x0,R.z1-t];}
function perimT(R,x,z){const w=R.x1-R.x0,h=R.z1-R.z0,cx=clamp(x,R.x0,R.x1),cz=clamp(z,R.z0,R.z1);const dT=cz-R.z0,dR=R.x1-cx,dB=R.z1-cz,dL=cx-R.x0,m=Math.min(dT,dR,dB,dL);
 if(m===dT)return cx-R.x0;if(m===dR)return w+(cz-R.z0);if(m===dB)return w+h+(R.x1-cx);return 2*w+h+(R.z1-cz);}
function nearBlock(min,max){const c=blocks.filter(B=>{const d=Math.hypot((B.x0+B.x1)/2-player.pos.x,(B.z0+B.z1)/2-player.pos.z);return d>min&&d<max;});return c.length?pick(c):pick(blocks);}
function attachPed(p){const B=blocks[clamp(Math.floor(p.pos.x/CELL),0,N-1)*N+clamp(Math.floor(p.pos.z/CELL),0,N-1)];p.R=perim(B);p.t=perimT(p.R,p.pos.x,p.pos.z);p.mode='walk';}
function newPedChar(p,B){if(p.c)removeChar(p.c);let role=pedRoleFor(B);if(role==='mb')role=ROLE.mb?'mb':'m';if(role==='fb')role=ROLE.fb?'fb':'f';const name=pickChar(role);p.c=makeChar(name,{});p.c.root.visible=false;p.tough=CAST[name]==='m'&&Math.random()<.3||CAST[name]==='gang';p.fem=/Female/.test(name);}
function placePed(p,B,stand){newPedChar(p,B);p.R=perim(B);p.t=rnd(0,200);const q=perimPos(p.R,p.t);p.pos.set(q[0],0,q[1]);p.mode='walk';p.dead=false;p.hp=60;p.dir=Math.random()<.5?1:-1;p.spd=rnd(1.15,1.55)*(p.fem?.95:1);p.cash=rint(5,80);p.fleeT=0;p.downT=0;p.c.talk=0;
 if(stand){p.mode='stand';p.standT=rnd(8,25);p.c.talk=Math.random()<.7?1:0;p.c.yaw=rnd(0,6);}}
function scare(x,z,r){for(const p of peds){if(p.dead||p.mode==='fight')continue;const dx=p.pos.x-x,dz=p.pos.z-z,d=Math.hypot(dx,dz);if(d<r){p.mode='flee';p.c.talk=0;p.fleeT=rnd(5,8);const a=Math.atan2(dx,dz)+rnd(-.6,.6);p.fv.set(Math.sin(a),0,Math.cos(a));}}}
function killPed(p,vx,vy,vz,crimeIt){if(p.dead)return;p.dead=true;p.mode='down';p.downT=0;p.c.hands=0;p.c.talk=0;ragdoll(p.c,vx,vy,vz);dropCash(p.pos.x,p.pos.z,p.cash);p.cash=0;if(crimeIt)crime(15,p.pos.x,p.pos.z);}
function hitPed(p,dmg,dx,dz,melee){if(p.dead)return;p.hp-=dmg;const l=Math.hypot(dx,dz)||1;
 if(p.hp<=0){killPed(p,dx/l*(melee?3:4),melee?2:1.5,dz/l*(melee?3:4),false);crime(melee?8:15,p.pos.x,p.pos.z);return;}
 crime(melee?3:10,p.pos.x,p.pos.z);
 if(melee&&p.tough){p.mode='fight';p.fightCd=.6;}else{p.mode='flee';p.fleeT=rnd(5,8);const a=Math.atan2(p.pos.x-player.pos.x,p.pos.z-player.pos.z);p.fv.set(Math.sin(a),0,Math.cos(a));}p.pos.x+=dx/l*.25;p.pos.z+=dz/l*.25;}
function ejectPed(x,z,fromX,fromZ){let best=null,bd=-1;for(const p of peds){const d=dist2(p.pos,player.pos)+(p.dead?500:0);if(d>bd){bd=d;best=p;}}if(!best)return;
 if(best.c)removeChar(best.c);best.c=makeChar(pickChar(Math.random()<.5?'m':'f'),{});best.dead=false;best.hp=60;best.pos.set(x,0,z);best.mode='flee';best.fleeT=6;const a=Math.atan2(x-fromX,z-fromZ);best.fv.set(Math.sin(a),0,Math.cos(a));best.cash=rint(10,60);}
function carHitsBody(pos,r){for(const k of cars){const rv=Math.abs(k.speed);if(rv<4)continue;const dx=pos.x-k.pos.x,dz=pos.z-k.pos.z;const fx=Math.sin(k.h),fz=Math.cos(k.h);const f=dx*fx+dz*fz,l=dx*fz-dz*fx;if(Math.abs(f)<k.spec.L/2+r&&Math.abs(l)<k.spec.W/2+r)return k;}return null;}
function updPeds(dt){const pp=player.car?player.car.pos:player.pos;
 for(const p of peds){const c=p.c;const dP=dist2(p.pos,pp);
  if(p.dead){p.downT+=dt;if(c.body){p.pos.set(c.body.position.x,0,c.body.position.z);}updChar(c,0,dt,dP<95);if(p.downT>30&&dP>50)placePed(p,nearBlock(50,130));continue;}
  if(dP>165){placePed(p,nearBlock(50,125),Math.random()<.22);continue;}
  const ox=p.pos.x,oz=p.pos.z;
  if(p.mode==='flee'){p.fleeT-=dt;p.pos.addScaledVector(p.fv,(p.fem?4.6:5.4)*dt);c.hands=0;const n=collideWorld(p.pos,.3);if(n){const a=Math.atan2(p.fv.x,p.fv.z)+(Math.random()<.5?1.5:-1.5);p.fv.set(Math.sin(a),0,Math.cos(a));}if(p.fleeT<=0)attachPed(p);}
  else if(p.mode==='fight'){const dx=player.pos.x-p.pos.x,dz=player.pos.z-p.pos.z,d=Math.hypot(dx,dz);c.guard=1;
   if(player.car||d>25||state!=='play'){p.mode='flee';p.fleeT=4;c.guard=0;}
   else if(d>1.25){p.pos.x+=dx/d*4.5*dt;p.pos.z+=dz/d*4.5*dt;collideWorld(p.pos,.3);}
   else{p.fightCd-=dt;if(p.fightCd<=0){p.fightCd=rnd(.7,1.1);c.punch=0;if(Math.random()<.6){damagePlayer(7);noise(.12,280,.45);}}}
   c.yaw=lerpA(c.yaw,Math.atan2(dx,dz),1-Math.exp(-12*dt));}
  else if(p.mode==='cower'){c.hands=1;p.cowerT-=dt;if(p.cowerT<=0){c.hands=0;p.mode='flee';p.fleeT=6;const a=Math.atan2(p.pos.x-player.pos.x,p.pos.z-player.pos.z);p.fv.set(Math.sin(a),0,Math.cos(a));}}
  else if(p.mode==='stand'){p.standT-=dt;if(p.standT<=0){p.mode='walk';c.talk=0;attachPed(p);}}
  else{p.t+=p.dir*p.spd*dt;const q=perimPos(p.R,p.t);const dx=q[0]-p.pos.x,dz=q[1]-p.pos.z,d=Math.hypot(dx,dz);if(d>.01){const st=Math.min(d,p.spd*1.8*dt);p.pos.x+=dx/d*st;p.pos.z+=dz/d*st;}if(d>3)p.t-=p.dir*p.spd*dt;}
  const mx=p.pos.x-ox,mz=p.pos.z-oz,spd=Math.hypot(mx,mz)/Math.max(dt,1e-4);if(spd>.2&&p.mode!=='fight')c.yaw=lerpA(c.yaw,Math.atan2(mx,mz),1-Math.exp(-9*dt));
  const hit=carHitsBody(p.pos,.3);if(hit){const s=Math.abs(hit.speed);killPed(p,hit.vel.x*1.1,2+s*.25,hit.vel.z*1.1,false);if(hit===player.car){scare(p.pos.x,p.pos.z,18);crime(10,p.pos.x,p.pos.z);shake=Math.max(shake,.3);}noise(.2,400,distVol(p.pos.x,p.pos.z,.6));continue;}
  if(!player.car&&dP<.7){const dx=p.pos.x-player.pos.x,dz=p.pos.z-player.pos.z,d=dP||1;p.pos.x=player.pos.x+dx/d*.7;p.pos.z=player.pos.z+dz/d*.7;}
  const vis=dP<85;c.root.visible=vis;const gy=groundY(p.pos.x,p.pos.z);c.root.position.set(p.pos.x,c.root.position.y+(gy-c.root.position.y)*Math.min(1,dt*12),p.pos.z);updChar(c,spd,dt,vis);}}
/* ---- law, gang, guards ---- */
function spawnUnit(kind,x,z,team){const role=kind==='swat'?'swat':kind==='army'?'army':kind==='gang'?'gang':kind==='guard'?'guard':'cop';
 const c=makeChar(pickChar(role),{gun:1,shadow:false});const hp={swat:180,army:220,gang:90,guard:120,cop:100}[role];
 const u={c,kind:role,pos:new V3(x,0,z),hp,cd:rnd(.6,1.4),team:team||'law',hostile:team!=='gang',dead:false,downT:0};collideWorld(u.pos,.35);c.root.position.copy(u.pos);(team==='gang'?gang:team==='guard'?guards:cops).push(u);return u;}
function removeUnit(u,arr){removeChar(u.c);const i=arr.indexOf(u);if(i>=0)arr.splice(i,1);}
function unitShootFrom(x,y,z,acc,dmg){const tgt=player.car?player.car.pos:player.pos;const a=new V3(x,y,z);
 const ac2=acc*(player.car?(Math.abs(player.car.speed)>15?.55:.85):(player.spd>5?.7:1));const hit=Math.random()<ac2;
 const b=new V3(tgt.x+(hit?0:rnd(-2.5,2.5)),hit?1.2:rnd(.4,2.4),tgt.z+(hit?0:rnd(-2.5,2.5)));tracer(a,b);emit(a.x,a.y,a.z,0,0,0,.06,.5,.8,0xffd080,true);noise(.15,2200,distVol(a.x,a.z,.35));
 if(hit&&state==='play'){if(player.car)damageCar(player.car,dmg*.6);else damagePlayer(dmg);}}
function unitShoot(u,acc,dmg){u.c.aim=.5;unitShootFrom(u.pos.x,u.c.root.position.y+1.45,u.pos.z,acc,dmg);}
function updUnits(arr,dt){const tgt=player.car?player.car.pos:player.pos;
 for(const u of arr.slice()){const c=u.c;
  if(u.dead){u.downT+=dt;if(c.body)u.pos.set(c.body.position.x,0,c.body.position.z);updChar(c,0,dt,true);if(u.downT>16)removeUnit(u,arr);continue;}
  const dx=tgt.x-u.pos.x,dz=tgt.z-u.pos.z,d=Math.hypot(dx,dz);const see=d<70&&los(u.pos,tgt);let spd=0,shoot=false,acc=.3,dmg=8;
  if(u.team==='law'){
   if(d>110||(wanted===0&&d>40)){removeUnit(u,arr);continue;}
   if(wanted===0||state!=='play'){c.yaw=lerpA(c.yaw,Math.atan2(dx,dz),dt*3);}
   else{const L=wanted;acc=u.kind==='army'?.55:u.kind==='swat'?.45:LV.acc[L];dmg=LV.dmg[L];
    const armed=player.weapon!=='fist'||time-lastShot<6||u.attacked;const melee=L===1||(L===2&&!armed&&!player.car);
    const want=melee&&!player.car?1.1:see?(u.kind==='cop'?12:15):1.5;
    if(d>want){spd=d<16?3.8:5.8;u.pos.x+=dx/d*spd*dt;u.pos.z+=dz/d*spd*dt;const n=collideWorld(u.pos,.35);if(n){const s=Math.sign(dx*-n[1]+dz*n[0])||1;u.pos.x+=-n[1]*s*spd*dt;u.pos.z+=n[0]*s*spd*dt;}}
    if(melee){c.guard=d<3?1:0;if(d<1.6&&!player.car){u.cd-=dt;if(u.cd<=0){u.cd=1;c.punch=0;damagePlayer(LV.dmg[1]);noise(.1,300,.4);}player.arrestT+=dt;}}else shoot=see&&d<34;}}
  else if(u.team==='gang'){if(d>9999){removeUnit(u,arr);continue;}
   if(!u.hostile&&!player.car&&d<9&&player.weapon!=='fist'&&player.c.aim>0)u.hostile=true;
   if(u.hostile&&state==='play'){acc=.3;dmg=7;if(d>14&&see){spd=4.5;u.pos.x+=dx/d*spd*dt;u.pos.z+=dz/d*spd*dt;collideWorld(u.pos,.35);}shoot=see&&d<30;}else{c.talk=1;}}
  else if(u.team==='guard'){acc=.35;dmg=8;if(d>80){removeUnit(u,arr);continue;}if(state==='play'&&see&&d<30)shoot=true;}
  if(shoot||spd>0||(u.hostile&&u.team!=='gang'&&wanted>0))c.yaw=lerpA(c.yaw,Math.atan2(dx,dz),1-Math.exp(-10*dt));
  if(shoot){u.cd-=dt;c.aim=Math.max(c.aim,.3);if(u.cd<=0){u.cd=u.kind==='army'||u.kind==='swat'?rnd(.35,.6):rnd(.7,1.3);unitShoot(u,acc,dmg);}}
  const hit=carHitsBody(u.pos,.35);if(hit&&(hit===player.car||u.team!=='law')){hitUnit(u,999,hit.vel.x,hit.vel.z,false,true,hit);if(hit===player.car)crime(u.team==='law'?35:5,u.pos.x,u.pos.z,u.team==='law');continue;}
  if(!player.car&&d<.8){u.pos.x=tgt.x-dx/(d||1)*.8;u.pos.z=tgt.z-dz/(d||1)*.8;}
  const vis=d<90;c.root.visible=vis;c.root.position.set(u.pos.x,groundY(u.pos.x,u.pos.z),u.pos.z);updChar(c,spd,dt,vis);}}
function hitUnit(u,dmg,dx,dz,melee,blast,car){if(u.dead)return;u.hp-=dmg;u.attacked=true;if(u.team==='gang')for(const g of gang)g.hostile=true;
 if(u.hp<=0){u.dead=true;u.downT=0;const l=Math.hypot(dx,dz)||1,s=car?Math.abs(car.speed):0;ragdoll(u.c,car?car.vel.x*1.1:dx/l*(blast?8:3),car?2+s*.25:(blast?6:1.5),car?car.vel.z*1.1:dz/l*(blast?8:3));
  if(u.team==='law'){crime(u.kind==='cop'?35:45,u.pos.x,u.pos.z,true);dropPickup(u.kind==='cop'?'ammo':'ammo2',u.pos.x,u.pos.z);}
  else if(u.team==='gang'){dropCash(u.pos.x,u.pos.z,rint(40,160));crime(10,u.pos.x,u.pos.z);}else{crime(30,u.pos.x,u.pos.z,true);dropPickup('ammo',u.pos.x,u.pos.z);}}
 else if(u.team==='law')crime(melee?15:12,u.pos.x,u.pos.z,true);}
/* ---- helicopter ---- */
function makeHeli(army){const g=new THREE.Group();const bm=new THREE.MeshStandardMaterial({color:lin(army?0x4a5a3a:0x1a2a4a),roughness:.3,metalness:.5}),wm=new THREE.MeshStandardMaterial({color:lin(0xf2f2f2),roughness:.35,metalness:.3});
 const body=new THREE.Mesh(new THREE.SphereGeometry(1.6,20,14),bm);body.scale.set(1,.9,1.75);g.add(body);const stripe=new THREE.Mesh(new THREE.SphereGeometry(1.62,20,14,0,Math.PI*2,Math.PI*.52,Math.PI*.2),army?bm:wm);stripe.scale.set(1,.9,1.75);g.add(stripe);
 const win=new THREE.Mesh(new THREE.SphereGeometry(1.25,14,10,0,Math.PI*2,0,Math.PI/2),glassMat);win.rotation.x=Math.PI/2.3;win.position.set(0,.15,1.6);g.add(win);
 const tail=new THREE.Mesh(new THREE.CylinderGeometry(.18,.42,5.2,10),bm);tail.rotation.x=Math.PI/2;tail.position.set(0,.3,-4.3);g.add(tail);const fin=new THREE.Mesh(unitBox,bm);fin.scale.set(.1,1.3,.8);fin.position.set(0,.9,-6.6);g.add(fin);
 for(const s of[-1,1]){const sk=new THREE.Mesh(unitBox,darkMat);sk.scale.set(.1,.1,3.3);sk.position.set(s*1.1,-1.55,.2);g.add(sk);for(const z of[-.8,1])(()=>{const st=new THREE.Mesh(unitBox,darkMat);st.scale.set(.06,.5,.06);st.position.set(s*1.05,-1.3,z);g.add(st);})();}
 const rotor=new THREE.Group();for(let k=0;k<4;k++){const b=new THREE.Mesh(unitBox,darkMat);b.scale.set(.3,.04,9.5);b.rotation.y=k*Math.PI/4;rotor.add(b);}rotor.position.y=1.7;g.add(rotor);
 const tr=new THREE.Mesh(unitBox,darkMat);tr.scale.set(.05,1.6,.15);tr.position.set(.22,.9,-6.7);g.add(tr);
 const beam=new THREE.Mesh(new THREE.CylinderGeometry(.3,5,1,24,1,true),new THREE.MeshBasicMaterial({color:new THREE.Color(1,.95,.85),transparent:true,opacity:.025,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}));
 const spot=new THREE.Mesh(new THREE.CircleGeometry(4.5,28),new THREE.MeshBasicMaterial({map:glowTex(),color:new THREE.Color(1.4,1.3,1.1),transparent:true,opacity:.55,blending:THREE.AdditiveBlending,depthWrite:false}));spot.rotation.x=-Math.PI/2;
 const nav=new THREE.Mesh(new THREE.SphereGeometry(.12,6,6),new THREE.MeshBasicMaterial({color:new THREE.Color(4,.2,.2)}));nav.position.set(0,-.9,1.4);g.add(nav);
 scene.add(g,beam,spot);g.traverse(o=>{if(o.isMesh)o.castShadow=true;});const a=Math.random()*6;
 return{g,rotor,tr,beam,spot,nav,pos:new V3(player.pos.x+Math.cos(a)*150,34,player.pos.z+Math.sin(a)*150),vel:new V3(),sp:player.pos.clone(),hp:army?500:380,cd:2,dead:false,army,ang:rnd(0,6)};}
function updHelis(dt){const tgt=player.car?player.car.pos:player.pos;
 for(const h of helis.slice()){h.rotor.rotation.y+=dt*28;h.tr.rotation.x+=dt*40;h.nav.visible=(time*2|0)%2===0;
  if(h.dead){h.vel.y-=14*dt;h.pos.addScaledVector(h.vel,dt);h.g.rotation.y+=dt*4;h.beam.visible=h.spot.visible=false;if(Math.random()<.8)emit(h.pos.x,h.pos.y,h.pos.z,rnd(-1,1),rnd(1,3),rnd(-1,1),1.5,1.5,5,0x2a2624,false);
   if(h.pos.y<=1.2){explodeAt(h.pos.x,h.pos.z,11);scene.remove(h.g,h.beam,h.spot);helis.splice(helis.indexOf(h),1);}else h.g.position.copy(h.pos);continue;}
  const L=wanted;if(L<4){h.pos.y+=dt*8;h.pos.x+=dt*25;if(h.pos.y>95){scene.remove(h.g,h.beam,h.spot);helis.splice(helis.indexOf(h),1);continue;}}
  else{const ls=L===5?15:11;_v.set(tgt.x-h.sp.x,0,tgt.z-h.sp.z);const dl=_v.length();if(dl>ls*dt)_v.multiplyScalar(ls*dt/dl);h.sp.add(_v);
   h.ang+=dt*.25;const want=new V3(h.sp.x+Math.cos(h.ang)*22,32+Math.sin(time*.7)*2,h.sp.z+Math.sin(h.ang)*22);_v.subVectors(want,h.pos);const dl2=_v.length();if(dl2>22*dt)_v.multiplyScalar(22*dt/dl2);h.pos.add(_v);}
  h.g.position.copy(h.pos);h.g.rotation.y=lerpA(h.g.rotation.y,Math.atan2(h.sp.x-h.pos.x,h.sp.z-h.pos.z),dt*2);h.g.rotation.x=.1;
  const blen=Math.hypot(h.sp.x-h.pos.x,h.pos.y,h.sp.z-h.pos.z);h.beam.position.set((h.pos.x+h.sp.x)/2,h.pos.y/2,(h.pos.z+h.sp.z)/2);h.beam.scale.set(1,blen,1);h.beam.lookAt(h.sp.x,0,h.sp.z);h.beam.rotateX(Math.PI/2);
  h.spot.position.set(h.sp.x,groundY(h.sp.x,h.sp.z)+.05,h.sp.z);h.beam.visible=h.spot.visible=L>=4;h.spotted=L>=4&&dist2(h.sp,tgt)<6;
  if(L===5&&h.spotted&&state==='play'){h.cd-=dt;if(h.cd<=0){h.cd=rnd(.25,.45);const a=new V3(h.pos.x,h.pos.y-1.5,h.pos.z);const hit=Math.random()<.3;const b=new V3(tgt.x+(hit?0:rnd(-3,3)),hit?1.2:0,tgt.z+(hit?0:rnd(-3,3)));tracer(a,b);noise(.12,2500,distVol(a.x,a.z,.3));if(hit){if(player.car)damageCar(player.car,6);else damagePlayer(9);}}}}}
/* ---- spawning ---- */
function laneSpot(minD,maxD){for(let t=0;t<60;t++){const a=[rint(0,N),rint(0,N)],nb=pick(neighbors(a)),dx=nb[0]-a[0],dz=nb[1]-a[1],f=rnd(.3,.7);const x=(a[0]+dx*f)*CELL-dz*LANE,z=(a[1]+dz*f)*CELL+dx*LANE,d=Math.hypot(x-player.pos.x,z-player.pos.z);
 if(d<minD||d>maxD)continue;if(cars.some(c=>Math.hypot(c.pos.x-x,c.pos.z-z)<10))continue;return{x,z,h:Math.atan2(dx,dz),a,b:nb};}return null;}
const TRAFFIC=['sedan','sedan','hatch','suv','sport','taxi','sedan','suv','taxi','hatch','van'];
function spawnTraffic(minD,maxD){const s=laneSpot(minD,maxD);if(!s)return;const c=spawnCar(pick(TRAFFIC),s.x,s.z,s.h,'ai');c.ai={a:s.a,b:s.b};c.speed=9;}
function spawnParked(x,z,h){if(x==null){for(let t=0;t<30;t++){const a=[rint(0,N),rint(0,N)],nb=pick(neighbors(a)),dx=nb[0]-a[0],dz=nb[1]-a[1],f=rnd(.3,.7);x=(a[0]+dx*f)*CELL-dz*6.6;z=(a[1]+dz*f)*CELL+dx*6.6;h=Math.atan2(dx,dz);if(!cars.some(c=>Math.hypot(c.pos.x-x,c.pos.z-z)<7))break;}}
 if(cars.some(c=>Math.hypot(c.pos.x-x,c.pos.z-z)<6))return null;return spawnCar(pick(['sedan','sport','suv','hatch','sedan','van']),x,z,h,null);}
function spawnPolice(chase){const L=wanted;const s=laneSpot(chase?55:60,chase?120:220);if(!s)return;let type='police',unit='cop';if(chase&&L>=4&&Math.random()<(L===5?.55:.4)){type='swat';unit=L===5&&Math.random()<.6?'army':'swat';}
 const c=spawnCar(type,s.x,s.z,s.h,'police');c.unit=unit;if(chase){c.route={b:nearestNode(c.pos)};c.speed=15;}else c.ai={a:s.a,b:s.b};}
function roadblock(){if(!player.car||Math.abs(player.car.speed)<10)return;const c=player.car,fx=Math.sin(c.h),fz=Math.cos(c.h);const n=nearestNode({x:c.pos.x+fx*110,z:c.pos.z+fz*110});const x=n[0]*CELL,z=n[1]*CELL;if(Math.hypot(x-c.pos.x,z-c.pos.z)<60||x<0||x>W)return;
 const alongX=Math.abs(fx)>Math.abs(fz);for(const s of[-1,1]){const px=alongX?x-Math.sign(fx)*13:x+s*3.6,pz=alongX?z+s*3.6:z-Math.sign(fz)*13;const k=spawnCar('police',px,pz,alongX?0:Math.PI/2,null);k.block=true;k.siren=true;k.blockT=0;spawnUnit('cop',px+(alongX?-Math.sign(fx)*3:s*2),pz+(alongX?s*2:-Math.sign(fz)*3));}
 for(let k=-2;k<=2;k++){const px=alongX?x-Math.sign(fx)*16:x+k*1.4,pz=alongX?z+k*1.4:z-Math.sign(fz)*16;PROPS.list.length;}toast('ROADBLOCK AHEAD',1400);}
let spawnT=0;
function manage(dt){spawnT-=dt;if(spawnT>0)return;spawnT=1;
 const ai=cars.filter(c=>c.driver==='ai');if(ai.length<(QUALITY.level>=2?22:15))spawnTraffic(70,170);
 for(const c of ai)if(dist2(c.pos,player.pos)>215){const s=laneSpot(85,160);if(s){physCarOff(c);c.pos.set(s.x,0,s.z);c.h=s.h;c.ai={a:s.a,b:s.b};c.vel.set(0,0,0);c.speed=9;}}
 const pol=cars.filter(c=>c.driver==='police'),foot=cops.filter(c=>!c.dead).length,L=wanted,quota=L?LV.cars[L]:2;
 if(pol.length+foot*.4<quota)spawnPolice(L>0);if(L===0)for(const c of pol)if(pol.length>2&&dist2(c.pos,player.pos)>170){removeCar(c);break;}
 const wantH=L>=5?2:L>=4?1:0;if(helis.filter(h=>!h.dead).length<wantH){heliT-=1;if(heliT<=0){helis.push(makeHeli(L===5&&helis.length>0));heliT=L===5?12:25;toast('POLICE CHOPPER INCOMING',1400);}}else heliT=Math.min(heliT,6);
 if(L>=3){roadblockT-=1;if(roadblockT<=0){roadblockT=L>=4?18:28;roadblock();}}
 for(const c of cars.slice())if(c.block){c.blockT+=1;if(c.blockT>70&&dist2(c.pos,player.pos)>60)removeCar(c);}
 const empty=cars.filter(c=>!c.driver&&c!==player.car&&!c.block&&!c.keep);for(const c of empty){const d=dist2(c.pos,player.pos);if((c.dead&&c.wreckT>25&&d>50)||(empty.length>18&&d>150&&!c.dead)){removeCar(c);break;}}
 for(const p of places)if(p.cd>0)p.cd=Math.max(0,p.cd-1);
 const court=blocks.find(B=>B.gang);if(court&&gang.length===0&&Math.hypot(court.gang.x-player.pos.x,court.gang.z-player.pos.z)>110)for(let k=0;k<4;k++)spawnUnit('gang',court.gang.x+rnd(-10,10),court.gang.z+rnd(-6,6),'gang');}
/* physics activation by distance */
function physLOD(){const px=player.pos.x,pz=player.pos.z;for(const c of cars){const d=Math.hypot(c.pos.x-px,c.pos.z-pz);if(!c.phys&&(d<110||c===player.car))physCarOn(c);else if(c.phys&&d>140&&c!==player.car&&(c.driver||c.body.sleepState===2)&&c.upY>.8)physCarOff(c);}}
/* ---- pickups ---- */
const PK={cash:[0x2ecc71,.42,.2,.28],health:[0xff2a3a,.34,.34,.15],armor:[0x2a7aff,.38,.42,.15],ammo:[0x7a8a3a,.45,.28,.28],ammo2:[0x5a6a8a,.45,.28,.28]};
function dropPickup(type,x,z,amount){const[c,sx,sy,sz]=PK[type];const m=new THREE.Mesh(unitBox,new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:.8,roughness:.4}));m.scale.set(sx,sy,sz);scene.add(m);const p={type,x:x+rnd(-.5,.5),z:z+rnd(-.5,.5),m,t:0,amount,fixed:false};pickups.push(p);return p;}
function dropCash(x,z,a){if(a>0)dropPickup('cash',x,z,a);}
function updPickups(dt){for(const p of pickups.slice()){p.t+=dt;if(p.cool>0){p.cool-=dt;p.m.visible=p.cool<=0;continue;}p.m.rotation.y+=dt*2.5;p.m.position.set(p.x,groundY(p.x,p.z)+.6+Math.sin(time*3+p.x)*.12,p.z);
 if(!p.fixed&&p.t>45){scene.remove(p.m);pickups.splice(pickups.indexOf(p),1);continue;}
 const pp=player.car?player.car.pos:player.pos;if(state==='play'&&Math.hypot(pp.x-p.x,pp.z-p.z)<(player.car?2.8:1.4)){let ok=true;
  if(p.type==='cash'){player.cash+=p.amount;toast('+$'+p.amount,900);beep(1400,.08,.15,'sine');}else if(p.type==='health'){if(player.hp>=100)ok=false;else{player.hp=Math.min(100,player.hp+40);toast('+HEALTH',900);}}
  else if(p.type==='armor'){player.armor=100;toast('+ARMOR',900);}else if(p.type==='ammo'){player.ammo.pistol+=12;toast('+12 PISTOL AMMO',900);}else if(p.type==='ammo2'){player.ammo.smg+=30;player.own.smg=true;toast('+30 SMG AMMO',900);}
  if(ok){if(p.fixed){p.cool=40;p.m.visible=false;}else{scene.remove(p.m);pickups.splice(pickups.indexOf(p),1);}}}}}
/* ---- markers ---- */
const markerObjs=[];
function labelSprite(text,color){const[c,g]=cvs(512,128);g.font='84px Anton, Impact, sans-serif';g.textAlign='center';g.textBaseline='middle';g.lineWidth=12;g.strokeStyle='rgba(0,0,0,.8)';g.strokeText(text,256,66);g.fillStyle=color;g.fillText(text,256,66);
 const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false,transparent:true,fog:false}));s.scale.set(8,2,1);s.renderOrder=9;return s;}
const MCOL={store:0xffd040,bank:0xffd040,gunshop:0xff8a30,hospital:0xff4060,police:0x4a8aff,chop:0x40ff80,spray:0x40a8ff};
function buildMarkers(){for(const p of places){const col=new THREE.Color(MCOL[p.kind]);const at=p.road||p.door;const r=p.road?4:1.3;const y=groundY(at.x,at.z);
 const ring=new THREE.Mesh(new THREE.RingGeometry(r*.78,r,40),new THREE.MeshBasicMaterial({color:col.clone().multiplyScalar(2),transparent:true,opacity:.75,depthWrite:false,side:THREE.DoubleSide,fog:false}));ring.rotation.x=-Math.PI/2;ring.position.set(at.x,y+.04,at.z);scene.add(ring);
 const beam=new THREE.Mesh(new THREE.CylinderGeometry(r,r,p.road?8:3,32,1,true),new THREE.MeshBasicMaterial({color:col.clone().multiplyScalar(1.5),transparent:true,opacity:.12,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,fog:false}));beam.position.set(at.x,(p.road?4:1.5)+y,at.z);scene.add(beam);REFL.hide.push(beam);
 const lab={store:'ROB $',bank:'ROB BANK',gunshop:'GUNS',hospital:'HEAL',police:'POLICE',chop:'SELL CAR',spray:'RESPRAY'}[p.kind];
 if(p.kind!=='police'){const l=labelSprite(lab,'#'+MCOL[p.kind].toString(16).padStart(6,'0'));l.position.set(at.x,p.road?9:4.6,at.z);l.scale.set(p.road?8:5,p.road?2:1.25,1);scene.add(l);p.label=l;REFL.hide.push(l);}
 markerObjs.push({p,ring,beam});}}
