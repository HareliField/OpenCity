# Commonstreet (v3)
Browser 3D GTA-style game. three.js r128 + cannon-es physics, Rocketbox characters, Poly Haven textures.

## Run
    python3 -m http.server 8765
    open http://localhost:8765/index.html
Phone/quality override: ?q=0|1|2

## Layout
- index.html: HUD and page shell
- js/: core (render/post), phys, cargen (procedural cars), chars, world, props, game, main
- models/: character glTF (json) + animations; tex/: textures and sky; lib/: three, loaders, cannon
- tools/: asset conversion/test scripts (not needed to run). Playwright tests use window.__game hooks.

## Notes for next steps
Cars are procedural (least realistic part); driving handling is untuned on real devices; phone performance unverified on hardware.
Credits: Rocketbox (MIT), Poly Haven (CC0), three.js, cannon-es.
